% MCMC settings for news shock application, real data, larger prior uncertainty

settings_news_dat;

nuts.num = 3e4; % Total number of steps (following adaptation)