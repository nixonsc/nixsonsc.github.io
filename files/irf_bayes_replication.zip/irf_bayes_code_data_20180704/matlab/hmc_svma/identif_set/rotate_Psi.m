function Psi_new = rotate_Psi(Psi, K)

    % Return rotated SVMA polynomial Psi_tilde(z) = Psi(z)*K

    [n, ~, qp1] = size(Psi);
    Psi_new = permute(reshape(reshape(permute(Psi, [1 3 2]), n*qp1, n)*K, n, qp1, n), [1 3 2]);

end