function Psi_fit = procrustes(Psi, Psi_target)

    % Solve orthogonal Procrustes problem to calculate best-fitting Psi polynomial
    % https://en.wikipedia.org/wiki/Orthogonal_Procrustes_problem

    n = size(Psi, 1);
    
    Psi_col = reshape(permute(Psi, [1 3 2]), [], n); % Place Psi_l matrices on top of each other
    Psi_target_col = reshape(permute(Psi_target, [1 3 2]), [], n); % Do the same for target polynomial
    
    [U, ~, V] = svd(Psi_col'*Psi_target_col); % Solve orthogonal Procrustes problem by SVD
    K = U*V'; % Best-fitting orthogonal matrix

    Psi_fit = rotate_Psi(Psi, K); % Rotate Psi polynomial

end