function [Psi_roots, Psi_check, gamma] = flip_root_Psi(Psi, varargin)
    
    % Flip roots of VMA polynomial as in Lippi & Reichlin (Journal of Econometrics, 1994)
    % MPM 2015-08-22
    
    % Arguments:
    % Psi           n x n x (q+1)   3-dimensional array with Psi_{ij,l} coefficients
    % varargin      1 x 1           (optional:) complex value of root that should be flipped
    
    % Outputs:
    % Psi_roots     nq x 1          roots of det(Psi(z))
    % Psi_check     n x n x (q+1)   3-dimensional array with new Psi_{ij,l} coefficients
    % gamma         1 x 1           value of root that was flipped
    
    
    [n,~,qp1] = size(Psi); % Dimensions of lag polynomial (qp1 = q+1)
    Psi_row = reshape(Psi,n,n*qp1); % Matrix (Psi_0, Psi_1, ..., Psi_q)
    Psi_inv_row = Psi(:,:,1)\Psi_row(:,n+1:end); % Matrix (Psi_0^(-1)Psi_1, ... Psi_0^(-1)Psi_q)
    
    comp = [-Psi_inv_row; eye(n*(qp1-2)) zeros(n*(qp1-2),n)]; % Companion matrix for matrix lag polynomial
    [comp_V, comp_D] = eig(comp); % Eigendecomposition of companion matrix
    [Psi_roots, I] = sort(1./diag(comp_D)); % Sort roots (inverse eigenvalues) by magnitude
    
    if nargout > 1; % If roots should be flipped...
    
        comp_V = comp_V(:,I); % Sort eigenvectors in same way

        [discrep, root_ind] = min(abs(Psi_roots - varargin{1})); % Find the index of the root in question
        if discrep > eps^(1/3); % If the root can't be found...
            warning(['Root not found. Discrepancy: ' num2str(discrep)]); % Throw warning
        end;

        gamma = Psi_roots(root_ind); % The root we wish to flip
        eta = comp_V(1:n,root_ind); % Vector eta that satisfies Psi(gamma)*eta = 0
        eta_bar = null(eta'); % Orthogonal matrix that is also orthogonal to eta
        K = [eta/sqrt(eta'*eta) eta_bar]; % Orthogonal matrix with first column proportional to eta

        Psi_check = rotate_Psi(Psi, K); % Rotate Psi(z) polynomial such that first column contains the factor (z - gamma)

        for i=1:n; % For each row of Psi(z)...

            the_poly = squeeze(Psi_check(i,1,end:-1:1)); % Polynomial coefficients of Psi_{i1}(z)

            % Deal with the special case where the lag polynomial has exact zero coefficients at the longest lags
            num_zeros = find(the_poly ~= 0) - 1; % Number of long lags with zero coefficients
            the_poly = the_poly(num_zeros+1:end); % Consider polynomial for the shorter lags
            the_roots = roots(the_poly); % Roots of the polynomial

            if length(the_roots) < length(the_poly)-1; % If Matlab finds less roots than the degree of the reduced polynomial, throw an error
                error('Multiple roots.');
            end;

            [~, root_to_flip] = min(abs(the_roots - gamma)); % Find the index of the root (gamma) that we want to flip
            the_roots_flipped = the_roots; % The list of flipped roots equals the original roots...
            the_roots_flipped(root_to_flip) = 1/conj(the_roots(root_to_flip)); % ... except that we change gamma to 1/conj(gamma)
            the_poly_flipped = poly(the_roots_flipped); % Polynomial coefficients corresponding to the flipped roots
            the_poly_flipped = the_poly_flipped*the_poly(1)*(-the_roots(root_to_flip)); % Scale polynomial so that the coefficient on z^q has the appropriate value

            Psi_check(i,1,1:end-num_zeros) = the_poly_flipped(end:-1:1); % Record flipped polynomial (remembering to add back the zeros at long lags)

        end;

        if ~isreal(gamma) && (min(abs(Psi_roots - conj(gamma))) < eps^(4/5)); % If the root above we flipped was not real and a complex conjugate root exists...
            
            [~, Psi_check] = flip_root_Psi(Psi_check, conj(gamma)); % ... also flip the complex conjugate root

        else % Otherwise, rotate lag polynomial to ensure real solution
            
            Psi_check0 = Psi_check(:,:,1); % New Psi_0 matrix
            Q = Psi_check0\(chol(Psi_check0*Psi_check0')'); % Orthogonal matrix such that (new) Psi_0*Q is lower triangular
            Psi_check = rotate_Psi(Psi_check, Q); % Rotate polynomial to enforce normalization

            Psi_check = real(Psi_check); % Remove any imaginary part due to rounding error
        
        end;
    
    end;

end