function Gamma = acf_svma(Psi)

    % ACF of SVMA model

    [n, ~, qp1] = size(Psi);
    Psi_row = reshape(Psi, n, n*qp1); % (Theta_0, Theta_1, ..., Theta_q)
    
    Gamma = zeros(n, n, qp1);
    
    for k=0:qp1-1;
        
        Gamma(:,:,k+1) = Psi_row(:,k*n+1:end)*Psi_row(:,1:(qp1-k)*n)'; % Gamma(k)
        
    end;

end