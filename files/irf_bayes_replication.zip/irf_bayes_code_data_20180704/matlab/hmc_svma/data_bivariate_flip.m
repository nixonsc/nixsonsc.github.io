% Simulated data for bivariate simulation example, misspecified roots

n = size(prior.mu,1);
inds = sub2ind([n n], prior.norm_var, 1:n); % Linear indices of normalized IR coef's
Psi_mode = bsxfun(@times, prior.mu, reshape(exp(prior.mu_sigma), 1, n, 1));
Psi_roots = flip_root_Psi(Psi_mode, []); % Roots of Psi polynomial
Psi_roots_trim = Psi_roots(imag(Psi_roots) >= 0); % Only keep one from each pair of complex roots (and keep all real roots)

[~, Psi_flip] = flip_root_Psi(Psi_mode, Psi_roots_trim(5));
Psi_rotate = rotate_Psi(Psi_flip, [1 -1; 1 1]/sqrt(2));

[Theta_true, sigma_true] = Psi_to_Theta(Psi_rotate, inds); % True IRFs and shock standard deviations

[Y, SVMA_model] = sim_svma(Theta_true, sigma_true, 200, prior); % Simulate data with T=200
disp(SVMA_model); % Display model specification
