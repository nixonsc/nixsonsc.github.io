% MCMC settings for news shock application, real data

nuts = struct;

nuts.adapt = 1200; % Adaptation period
nuts.num = 1e4; % Total number of steps (following adaptation)
nuts.burnin = 3e3; % Burn-in steps (following adaptation)
nuts.store_every = 10; % Store every X draws in chain (thinning)
nuts.target_rate = 0.5; % Target MCMC acceptance rate
nuts.mass_adapt = 1; % =1: Adapt to posterior std. dev. of parameters
nuts.mass_adapt_times = [0 100 300 700] + 300; % Times between which to adapt. First entry is when adaptation starts. At second entry, the first std. dev. estimate is produced. At third entry, second estimate is produced. Adaptation stops at last entry.
nuts.mass_adapt_shrinkage = 1e-3; % Shrinkage constant for adaptation, higher values mean estimated std. dev's are less variable between parameters
nuts.min_epsilon = 1e-4; % Minimum allowed step size
nuts.jitter = 0.5; % Step size jitter factor (after adaptation), btw 0 and 1 (0 = no jitter, 1 = jitter from 0% to 200%)
nuts.max_depth = 20; % Max NUTS tree depth
nuts.print_epsilon = 0; % =1: Display step size in each NUTS iteration
