% Data for news shock application

dat = importdata('../../stata/data_q_final.csv'); % Load CSV data
time = datenum(dat.textdata(2:end,1), 'yyyy-mm'); % Time stamps as Matlab serial numbers
Y_raw = 100*dat.data; % Convert raw data to percentages
[Y, Y_trend] = detrend_biweight(Y_raw, 100); % Extract cycle and trend using biweight filter with bandwidth of +/- 100 quarters


