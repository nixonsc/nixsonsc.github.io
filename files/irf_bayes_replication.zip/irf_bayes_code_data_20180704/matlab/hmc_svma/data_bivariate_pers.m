% Simulated data for bivariate simulation example, misspecified prior: persistence

Theta_true = bsxfun(@times, prior.mu, permute(exp(-0.25*(0:q)), [1 3 2])); % True IRFs with less persistence
Theta_true = bsxfun(@times, Theta_true, bsxfun(@rdivide, max(abs(prior.mu),[],3), max(abs(Theta_true),[],3))); % Re-scale so maximum effect is the same
sigma_true = exp(prior.mu_sigma); % True shock standard deviations

[Y, SVMA_model] = sim_svma(Theta_true, sigma_true, 200, prior); % Simulate data with T=200
disp(SVMA_model); % Display model specification
