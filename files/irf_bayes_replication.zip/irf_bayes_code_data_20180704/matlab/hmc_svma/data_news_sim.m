% Simulated data for news shock application

Theta_true = irf_grid(:,:,1:q+1); % True IRFs
sigma_true = exp(prior.mu_sigma); % True shock standard deviations

[Y, SVMA_model] = sim_svma(Theta_true, sigma_true, 213, prior); % Simulate data with T=213
disp(SVMA_model); % Display model specification
