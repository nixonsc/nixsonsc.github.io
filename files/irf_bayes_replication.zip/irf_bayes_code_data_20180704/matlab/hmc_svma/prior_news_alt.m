% Prior for news shock application, larger prior uncertainty

prior_news;

prior.tau(3,1,:) = 2*prior.tau(3,1,:);
prior.tau(3,3,:) = 2*prior.tau(3,3,:);
