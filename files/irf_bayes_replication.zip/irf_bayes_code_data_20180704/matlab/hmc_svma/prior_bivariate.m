% Prior for bivariate simulation example

prior = struct;

prior.var_names = {'FFR', 'Output gap'}; % Variable names
prior.shock_names = {'MP shock', 'Demand shock'}; % Shock names

q = 10; % Max IRF horizon

path_monotone = @(rate) exp(-rate*(0:q));
path_hump = @(top) betapdf(linspace(0, 1, q+1), 2, q/top)/betapdf(top/q, 2, q/top);

prior.mu = zeros(2,2,q+1); % IRF means
prior.mu(1,1,:) = path_monotone(0.3);
prior.mu(1,2,:) = path_hump(2);
prior.mu(2,1,:) = -path_hump(4) - 0.25*path_monotone(0.3); % Change hump top to 3 to get invertible IRFs
prior.mu(2,2,:) = path_monotone(0.3);

prior.tau = reshape(repmat(linspace(0.35, 0.05, q+1), 2^2, 1), [2 2 q+1]); % IRF standard deviations
prior.rho = 0.9*ones(2); % IRF smoothness

prior.norm_var = [1 2]; % Which response to normalize (i.e., fix) for each shock
prior.tau_sigma = 2*ones(1,2); % Std. dev's of log(sigma)
prior.mu_sigma = log([1 0.5]); % Means of log(sigma)
