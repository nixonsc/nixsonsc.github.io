function corrs = autocorr_var_res_sq(Y, lags)

    % Compute first autocorrelation of squared VAR residuals

    X = lagmatrix(Y, 1:lags); % Lagged data values
    X = [X ones(size(X,1), 1)]; % Add constant
    beta = X(lags+1:end,:)\Y(lags+1:end,:); % VAR regression
    u = Y(lags+1:end,:) - X(lags+1:end,:)*beta; % VAR residuals
    u_sq = u.^2; % Squared VAR residuals
    u_sq_dm = bsxfun(@minus, u_sq, mean(u_sq)); % De-mean
    corrs = mean(u_sq_dm(2:end,:).*u_sq_dm(1:end-1,:))./var(u_sq,1); % First autocorr. of squared VAR residuals

end