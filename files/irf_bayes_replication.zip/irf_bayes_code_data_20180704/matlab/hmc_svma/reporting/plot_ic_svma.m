function [aic, bic, ll_max] = plot_ic_svma(Y, Y_tilde, max_q)

    % Plot AIC and BIC criteria for SVMA lag length q

    [T,n] = size(Y); % Dimensions
    the_acf = acf_data(Y, max_q); % Compute ACF of data
    
    ll_max = zeros(1,1+max_q); % Will contain maximized Whittle log likelihood values
    the_Psi_opt = zeros(1,0);
    obj = @(x) loglike_vec(Y_tilde, x); % Negative log likelihood objective
    optimopt = optimoptions('fminunc', 'Algorithm', 'trust-region', 'GradObj', 'on', 'MaxIter', 100, 'Display', 'notify'); % Optimization options
    
    disp('Computing information criteria...');
    for q=0:max_q; % For each value of q...
        
        [B, V] = innovations_algorithm(the_acf(:,:,1:q+1)); % Obtain initial reduced-form VMA(q) that approximately fits the ACF out to lag q
        the_Psi_init_new = rotate_Psi(cat(3,eye(n),B), chol(V)'); % Compute corresponding scaled IRFs Psi

        [the_Psi_opt_1, the_mll_min_1] = fminunc(obj, the_Psi_init_new(:)', optimopt); % Minimized negative Whittle log likelihood
        if q>0;
            [the_Psi_opt_2, the_mll_min_2] = fminunc(obj, [the_Psi_opt zeros(1,n^2)], optimopt); % Also do minimization starting at optimum for previous q (padded with zeros)
        else
            the_mll_min_2 = Inf;
        end;
        
        [the_ll_max, max_ind] = max([-the_mll_min_1 -the_mll_min_2]); % Find best optimum
        the_Psi_opt = the_Psi_opt_1;
        if max_ind == 2;
            the_Psi_opt = the_Psi_opt_2;
        end;
        
        ll_max(q+1) = the_ll_max; % Maximized Whittle log likelihood
        
        fprintf('%2s%3d\n', 'q=', q); % Print progress
        
    end;
    disp(' ');
    
    dim_param = n^2*(1:max_q+1); % Dimension of parameter vector for various values of q
    aic = 2*ll_max - 2*dim_param; % AIC criterion
    bic = 2*ll_max - log(T)*dim_param; % BIC criterion
    
    % Normalize log likelihood and IC values to start at 0
    ll_max = ll_max - ll_max(1);
    aic = aic - aic(1);
    bic = bic - bic(1);
    
    [max_aic, max_aic_ind] = max(aic); % Index of maximum AIC value
    [max_bic, max_bic_ind] = max(bic); % Index of maximum BIC value
    
    
    figure('Name', 'Data: Information criteria', 'Units', 'normalize', 'Position', [0.15 0.15 0.7 0.7]); % New figure
    
    plot(0:max_q, ll_max, '-k', 0:max_q, aic, '-r', 0:max_q, bic, '-b', 'LineWidth', 2); % log likelihood and AIC/BIC values
    the_ylim = [0 max([max_aic max_bic])*1.25]; % New vertical axis limits
    hold on;
    line((max_aic_ind-1)*ones(1,2), the_ylim, 'Color', 'k', 'LineStyle', '--'); % Mark maximum AIC value
    line((max_bic_ind-1)*ones(1,2), the_ylim, 'Color', 'k', 'LineStyle', '--'); % Mark maximum BIC value
    hold off;
    
    % Add AIC- and BIC-minimizing q's to horizontal axis values
    the_ticks = get(gca, 'XTick');
    set(gca, 'XTick', unique([the_ticks max_aic_ind-1 max_bic_ind-1]));
    
    ylim(the_ylim); % Vertical axis limits
    set(gca,'FontSize', 12); % Adjust plot font size
    legend({'Log likelihood', 'AIC', 'BIC'}, 'FontSize', 12, 'Location', 'SouthEast'); % Add legend

end