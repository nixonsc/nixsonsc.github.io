function plot_sigma_hist(sigma_draws, sigma_true, prior)

    % Histogram of sigma draws

    p = size(sigma_draws, 2); % Number of shocks    
    figure('Name', 'Posterior: shock std. devs', 'Units', 'normalize', 'Position', [0.1 0.2 0.8 0.6]); % New figure
    
    for j=1:p; % For each shock...
        
        subtightplot(1, p, j, [0.07 0.07], 0.07, 0.03); % New subplot
        
        histogram(sigma_draws(:,j), 'EdgeColor', 'none', 'FaceColor', 'b', 'Normalization', 'pdf'); % Histogram of posterior sigma draws
        hold on;
        the_xlim = xlim; % Record x axis limits
        xvals = linspace(0, 1.5*the_xlim(2), 200); % Values at which to evaluate prior pdf
        plot(xvals, lognpdf(xvals, prior.mu_sigma(j), prior.tau_sigma(j)), '-r', 'LineWidth', 2); % Plot prior pdf
        
        if ~isempty(sigma_true); % If true values are supplied...
            the_ylim = ylim; % Record y axis limits
            line(sigma_true(j)*ones(1,2), the_ylim, 'Color', 'k', 'LineWidth', 2); % Vertical line marking true value
        end;
        
        hold off;
        xlim([0 1.5*the_xlim(2)]); % Make sure x limits are maintained
        set(gca,'FontSize', 12); % Adjust plot font size
        title(prior.shock_names{j}, 'FontSize', 16, 'FontWeight', 'bold'); % Title
        
    end;

end