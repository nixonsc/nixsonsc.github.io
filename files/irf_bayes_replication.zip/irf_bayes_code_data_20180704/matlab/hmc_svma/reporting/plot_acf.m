function plot_acf(i, j, draws, nuts, acf_lags)

    % Plot ACFs

    store_every = nuts.store_every;
    qp1 = size(draws, 3); % Number of IRF horizons plus 1

    acfs = zeros(qp1,acf_lags+1); % Will contain ACFs
    for l=1:qp1; % For each IRF horizon...
        acfs(l,:) = autocorr(squeeze(draws(i,j,l,:)), acf_lags); % ACF for this horizon
    end;
    plot((0:acf_lags) * store_every, acfs);
    ylim([-1 1]); % Set y limit

end