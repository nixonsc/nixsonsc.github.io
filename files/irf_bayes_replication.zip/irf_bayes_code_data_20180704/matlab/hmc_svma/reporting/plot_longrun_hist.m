function plot_longrun_hist(i, j, Theta_draws, prior)
    
    % Plot histogram of long-run impulse responses

    hold on;

    if ~isempty(Theta_draws);
    
        % Histogram of long-run IR draws

        longrun_draws = sum(squeeze(Theta_draws(i,j,:,:)), 1); % Draws of long-run IRs (sum of IRs along horizon)
        histogram(longrun_draws, 'EdgeColor', 'none', 'FaceColor', 'b', 'Normalization', 'pdf'); % Histogram of long-run IR draws

    end;
    
    
    % Pdf of prior long-run IR distribution
    
    qp1 = size(prior.mu, 3);
    prior_V = prior_varblock(i, j, prior); % Var-cov matrix of IRs
    if prior.norm_var(j) == i; % If initial IR is normalized...
        prior_V(1,1) = 0; % Set its variance equal to 0
    end;
    longrun_mean = sum(prior.mu(i,j,:)); % Mean of long-run IR
    longrun_sd = sqrt(ones(1,qp1)*prior_V*ones(qp1,1)); % Std. dev. of long-run IR
    
    % Adjust horizontal axis
    if ~isempty(Theta_draws);
        the_xlim = xlim;
    else
        the_xlim = longrun_mean + 2*longrun_sd*[-1 1];
    end;
    the_xlim_expand = the_xlim + 0.5*(the_xlim(2)-the_xlim(1))*[-1 1];
    xvals = linspace(the_xlim_expand(1), the_xlim_expand(2), 200);
    
    plot(xvals, normpdf(xvals, longrun_mean, longrun_sd), '-r', 'LineWidth', 2); % Prior pdf of long-run IRF
    
    
    % Vertical line at zero
    the_ylim = ylim;
    line([0 0], the_ylim, 'Color', 'k');
    
    xlim(the_xlim_expand);
    ylim(the_ylim);
    
    hold off;

end