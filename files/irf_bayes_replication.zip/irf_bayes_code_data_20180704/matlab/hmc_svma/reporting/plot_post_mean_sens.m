function plot_post_mean_sens(Theta_draws, log_sigma_draws, prior)

    % Plot M�ller (JME 2012) prior sensitivity (PS) measure for each IR
    

    [n,~,qp1,~] = size(Theta_draws); % Dimensions

    ps = zeros(n,n,qp1); % Will contain PS measure for each IR

    for i=1:n; % For each variable...

        for j=1:n; % For each shock...
            
            for l=0:qp1-1; % For each horizon...
                
                if l > 0 || prior.norm_var(j) ~= i; % If the IR is not normalized...
                    
                    post_cov_Theta = mean(bsxfun(@times, bsxfun(@minus, Theta_draws, mean(Theta_draws, 4)), Theta_draws(i,j,l+1,:)), 4); % Posterior covariance of Theta_{ij,l} with other IRs
                    post_cov_log_sigma = mean(bsxfun(@times, bsxfun(@minus, log_sigma_draws, mean(log_sigma_draws, 1)), squeeze(Theta_draws(i,j,l+1,:)))); % Posterior covariance of Theta_{ij,l} with log(sigma) parameters
                    
                    eval_Theta = prior.mu + post_cov_Theta; % Will be equal to prior mean for normalized coefficients
                    eval_log_sigma = prior.mu_sigma + post_cov_log_sigma;
                    
                    ps(i,j,l+1) = sqrt(-2*prior_svma(prior, eval_Theta, eval_log_sigma, [])); % Compute PS measure as prior log density evaluated at appopriate point
                    
                end;
                
            end;
            
        end;
        
    end;
    
    post_mean = mean(Theta_draws, 4); % Posterior means for IRs
    
    plot_tile( @(i,j) plot_irf(i, j, [], [], [], post_mean, post_mean-ps, post_mean+ps, [], [], []), 'Posterior: prior sensitivity', prior); % Plot posterior means with +/- PS band around them

end