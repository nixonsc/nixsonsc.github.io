function plot_FEVD(Theta_draws, log_sigma_draws, signif_level, plot_name, prior)

    % Compute and plot Forecast Error Variance Decomposition draws

    Psi_squared_draws = bsxfun(@times, Theta_draws, permute(exp(log_sigma_draws), [3 2 4 1])).^2; % Draws of Psi_{ij,l}^2
    
    numer = cumsum(Psi_squared_draws, 3); % Numerators in FEVD
    fevd = bsxfun(@rdivide, numer, sum(numer, 2)); % Normalize to sum to 1
    
    means = mean(fevd, 4);
    lower = quantile(fevd, signif_level/2, 4);
    upper = quantile(fevd, 1-signif_level/2, 4);
    
    plot_tile( @(i,j) plot_irf(i, j, [], [], [], means, lower, upper, [], [], [0 1]), plot_name, prior); % Plot bar plot for each horizon

end