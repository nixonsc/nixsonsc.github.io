function [Theta, sigma] = Psi_to_Theta(Psi, inds)
    
    % Convert Psi representation to (Theta,sigma)

    Psi0_signs = sign(Psi(inds));
    Psi_check = bsxfun(@times, Psi, Psi0_signs);
    
    sigma = Psi_check(inds);
    Theta = bsxfun(@rdivide, Psi_check, sigma);
    
end