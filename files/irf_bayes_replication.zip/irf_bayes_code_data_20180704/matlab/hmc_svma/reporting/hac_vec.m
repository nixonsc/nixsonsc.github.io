function lrv = hac_vec(Y, kernel, bw)

    % Compute HAC time-domain kernel estimator for vector time series

    [T,n] = size(Y); % Dimensions
    Y = bsxfun(@minus, Y, mean(Y)); % De-mean
    
    lrv = zeros(1,n); % Initialize LRV estimates at zero
    
    for k=0:bw-1; % For each lag...
        
        contrib = sum(Y(k+1:end,:).*Y(1:end-k,:))/T; % k-th autocovariances
        weight = kernel(k/bw)*(1 + (k>0)); % Weight of k-th autocovariance
        lrv = lrv + weight*contrib; % Add to LRV estimates
        
    end;

end