function results_svma(Theta_draws, log_sigma_draws, accepts, elapsed_time, ...
                      Theta_true, sigma_true, Y, time, ...
                      plot_post_extra, plot_post_inv, plot_post_pred, plot_post_shocks, plot_post_sens, signif_level, ...
                      R_square_lags, autocorr_draws_prior, smallest_root_draws_prior, R_square_draws_prior, check_fcts, check_fct_titles, ...
                      prior, nuts)
    
    % Show results of NUTS algorithm through plots and numbers
    
    
    num_stored_draws = size(Theta_draws,4); % Number of stored draws
    num_draws = length(accepts); % Total number of draws
    burnin_stored = nuts.burnin / nuts.store_every; % Number of stored draws to discard as burn-in
    acf_lags = min(floor(num_stored_draws / 10), round(1e3/nuts.store_every)); % Maximum ACF lag to consider
    
    
    % Plots of Theta draws
    plot_tile( @(i,j) plot_chain(i, j, Theta_draws, nuts), ...
               'Chain: IRFs', prior); % Plot Theta chains (including burn-in)
    
    plot_tile( @(i,j) plot_acf(i, j, Theta_draws(:,:,:,burnin_stored+1:end), nuts, acf_lags), ...
               'ACF: IRFs', prior); % Plot Theta ACFs (after burn-in)

    post_means = mean(Theta_draws(:,:,:,burnin_stored+1:end), 4);
    post_lower = quantile(Theta_draws(:,:,:,burnin_stored+1:end), signif_level/2, 4);
    post_upper = quantile(Theta_draws(:,:,:,burnin_stored+1:end), 1-signif_level/2, 4);
    
    plot_tile( @(i,j) plot_irf(i, j, Theta_true, prior.mu-norminv(1-signif_level/2)*prior.tau, prior.mu+norminv(1-signif_level/2)*prior.tau, post_means, post_lower, post_upper, [], [], []), ...
               'Posterior: IRFs', prior); % Plot true Theta, prior bands, as well as posterior means and credible bands (after burn-in)
    
    % sigma chain plot (including burn-in)
    figure('Name', 'Chain: log shock std. devs', 'Units', 'normalize', 'Position', [0.1 0.2 0.8 0.6]); % New figure
    plot_chain(1, 1, permute(log_sigma_draws, [3 4 2 1]), nuts); % Plot chain of log(sigma)
    set(gca,'FontSize', 12); % Adjust plot font size
    legend(prior.shock_names, 'FontSize', 12, 'Location', 'SouthWest');

    % sigma ACF plot (after burn-in)
    figure('Name', 'ACF: log shock std. devs', 'Units', 'normalize', 'Position', [0.1 0.2 0.8 0.6]); % New figure
    plot_acf(1, 1, permute(log_sigma_draws, [3 4 2 1]), nuts, acf_lags); % Plot chain of log(sigma)
    set(gca,'FontSize', 12); % Adjust plot font size
    legend(prior.shock_names, 'FontSize', 12, 'Location', 'SouthWest');

    plot_sigma_hist(exp(log_sigma_draws(burnin_stored+1:end,:)), sigma_true, prior); % Plot histograms of sigma draws (after burn-in)
    
    % Numbers
    disp('Elapsed time (minutes)');
    disp(elapsed_time/60);
    
    disp('Total number of draws');
    disp(num_draws);
    
    disp('Burn-in');
    disp(nuts.burnin);
    
    disp('Number of stored draws after burn-in');
    disp(num_stored_draws - burnin_stored);
    
    disp('Acceptance frequency after burn-in');
    disp(mean(accepts(nuts.burnin+1:end)));
    
    
    if plot_post_extra == 1; % If long-run IRFs, FEVD, and autocorrelations should be plotted...
        
        plot_tile(@(i,j) plot_longrun_hist(i, j, Theta_draws(:,:,:,burnin_stored+1:end), prior), 'Posterior: long-run IRs', prior); % Plot histogram of long-run IRs
        plot_FEVD(Theta_draws(:,:,:,burnin_stored+1:end), log_sigma_draws(burnin_stored+1:end,:), signif_level, 'Posterior: FEVD', prior); % Plot FEVD
        plot_autocorr(Theta_draws(:,:,:,burnin_stored+1:end), log_sigma_draws(burnin_stored+1:end,:), signif_level, 'Posterior: Autocorr.', prior, autocorr_draws_prior, Theta_true, sigma_true); % Plot autocorrelations
    
    end;
    
    
    if plot_post_inv == 1; % If figures related to invertibility should be produced...
        
        plot_smallest_root(Theta_draws(:,:,:,burnin_stored+1:end), Theta_true, 'Posterior: smallest MA root', smallest_root_draws_prior); % Histogram of smallest MA root
        plot_R_square(Theta_draws(:,:,:,burnin_stored+1:end), log_sigma_draws(burnin_stored+1:end,:), R_square_lags, 'Posterior: R-square', prior, R_square_draws_prior); % Histogram of R-square values from regressions of shocks on lagged data
        plot_closest_invert(Theta_draws(:,:,:,burnin_stored+1:end), log_sigma_draws(burnin_stored+1:end,:), signif_level, 'Posterior: closest invertible IRFs', prior); % Plot distribution of invertible IRFs that are closest to the true IRF
        
    end;
    
    if plot_post_shocks == 1; % If posterior means of structural shocks should be plotted...
        
        plot_shocks(Theta_draws(:,:,:,burnin_stored+1:end), log_sigma_draws(burnin_stored+1:end,:), signif_level, Y, time, prior);
        
    end;
    
    
    if plot_post_pred == 1; % If plots of posterior predictive checks should be produced...
        
        plot_pred_check(Y, Theta_draws(:,:,:,burnin_stored+1:end), log_sigma_draws(burnin_stored+1:end,:), check_fcts, check_fct_titles, 'Posterior: Predictive checks', prior); % Plot posterior predictive checks
        
    end;
    
    
    if plot_post_sens == 1; % If prior sensitivity plot should be produced...
        
        plot_post_mean_sens(Theta_draws(:,:,:,burnin_stored+1:end), log_sigma_draws(burnin_stored+1:end,:), prior); % Compute and plot M�ller (JME 2012) prior sensitivity (PS) measure for each IR
        
    end;

end