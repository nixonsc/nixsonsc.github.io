function plot_irf(i, j, main_irf, band_lower, band_upper, errorbar_center, errorbar_lower, errorbar_upper, samples, samples_colors, common_ylim, varargin)

    % Plot IRF: thick line, shaded band, errorbars, and thin colored lines
    
    hold on;
    
    % Determine number of IRF samples
    if ~isempty(samples);
        num_samples = size(samples, 4);
    else
        num_samples = 0;
    end;
    
    if ~isempty(band_lower); % If shaded band should be drawn...
        qp1 = size(band_lower, 3); % Longest IRF horizon
        fill([0:qp1-1, fliplr(0:qp1-1)], [squeeze(band_lower(i,j,:))', fliplr(squeeze(band_upper(i,j,:))')], 'b', 'FaceAlpha', 0.2, 'LineStyle', 'none'); % Shaded band
    end;
    
    if ~isempty(main_irf); % If main IRF should be drawn...
        qp1 = size(main_irf, 3); % Longest IRF horizon
        the_linestyle = '-k';
        if isempty(band_lower) && isempty(errorbar_center);
            the_linestyle = '-xk';
        end;
        plot(0:qp1-1, squeeze(main_irf(i,j,:)), the_linestyle, 'LineWidth', 2); % Main IRF
    end;
    
    if ~isempty(errorbar_center); % If error bars should be drawn...
        qp1 = size(errorbar_center, 3); % Longest IRF horizon
        errorbar(0:qp1-1, squeeze(errorbar_center(i,j,:)), squeeze(errorbar_center(i,j,:) - errorbar_lower(i,j,:)), squeeze(errorbar_upper(i,j,:) - errorbar_center(i,j,:)), '-rx'); % Plot error bars
    end;
    
    the_linestyle = '-'; % Default line style for samples
    if ~isempty(varargin); % If optional line style is supplied
        the_linestyle = varargin{1};
    end;
    
    for k=1:num_samples; % If samples should be drawn...
        qp1 = size(samples, 3); % Longest IRF horizon
        if k <= length(samples_colors);
            plot(0:qp1-1, permute(samples(i,j,:,k), [3 4 1 2]), 'LineStyle', the_linestyle, 'Color', samples_colors{k}); % Plot samples
        else
            plot(0:qp1-1, permute(samples(i,j,:,k), [3 4 1 2]), 'LineStyle', the_linestyle); % Plot samples
        end;
    end;
    
    line([0 qp1-1],[0 0], 'Color', 'k'); % Horizontal line at zero
    
    xlim([0 qp1-1]); % Set x limits
    
    if ~isempty(common_ylim);
        ylim(common_ylim);
    end;
    
    hold off;

end