function sr_abs = smallest_root(Theta)

    % Returns absolute value of smallest root (in absolute value) of SVMA polynomial

    Theta_cell = num2cell(Theta, [1 2]); % Convert MA coefficient matrices into cell array
    
    if rcond(Theta_cell{1}) < eps^(2/3);
        warning('MA0 matrix is nearly singular');
        sr_abs = 0;
    else
        model = vgxset('MA0', Theta_cell{1}, 'MA', Theta_cell(2:end)); % Specify SVMA model
        [~,~,~,MAeig] = vgxqual(model);
        sr_abs = 1./abs(MAeig);
    end;

end