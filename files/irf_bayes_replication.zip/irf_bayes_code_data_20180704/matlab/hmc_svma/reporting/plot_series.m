function plot_series(Y, Y2, time, plot_name, prior)

    % Create time series plot

    [T,n] = size(Y);
    
    time_supplied = ~isempty(time); % Is vector of timestamps supplied?
    if ~time_supplied; % If not...
        time = 1:T; % Set timestamp equal to observation number
    end;
    
    figure('Name', plot_name, 'Units', 'normalize', 'Position', [0.1 0.1 0.8 0.8]); % New figure
    
    for i=1:n; % For each series...
        
        subtightplot(n, 1, i, [0.1 0.1], 0.07, 0.03); % New subplot
        plot(time, Y(:,i), '-k', 'LineWidth', 1); % Plot first set of series in black
        if time_supplied && time(1)>0;
            datetick('x', ' yy '); % Format dates as two-digit years
        end;
        hold on;
        
        if ~isempty(Y2);
            plot(time, Y2(:,i), '-r', 'LineWidth', 1); % Plot second set of series in red
        end;
        
        line([time(1) time(end)], [0 0], 'Color', 'k'); % Horizontal axis
        hold off;
        xlim([time(1) time(end)]);
        set(gca,'FontSize', 12); % Adjust plot font size
        title(prior.var_names{i}, 'FontSize', 16, 'FontWeight', 'bold');
        
    end;

end