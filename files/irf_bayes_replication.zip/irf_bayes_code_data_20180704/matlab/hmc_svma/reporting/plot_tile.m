function plot_tile(plot_fct, plot_name, prior)

    % Figure with tiled subplots

    var_names = prior.var_names;
    shock_names = prior.shock_names;
    n = length(var_names);

    titles = cell(1,n); % Will contain title handles
    
    figure('Name', plot_name, 'Units', 'normalize', 'Position', [0.1 0.1 0.8 0.8]); % New figure

    for i=1:n; % For each variable (along rows)...
        
        for j=1:n; % For each shock (along columns)...
            
            subtightplot(n, n, n*(i-1)+j, [0.07 0.07], 0.05, 0.07); % New subplot
            plot_fct(i,j); % Draw relevant plot
            set(gca,'FontSize', 12); % Adjust plot font size

            if i==1; % Write shock names along columns
                title(shock_names{j}, 'FontSize', 16, 'FontWeight', 'bold');
            end;
            
            if j==1; % Write variable names along rows
                titles{i} = ylabel(var_names{i}, 'FontSize', 16, 'FontWeight', 'bold');
            end;
            
        end;
        
    end;
    
    align_var_labels(titles); % Align variable labels horizontally

end