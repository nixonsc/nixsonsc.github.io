function [Psi, Theta, log_sigma, inds] = reparam_vec(prior, param_vec)

    % Compute Psi, Theta and log(sigma) from vectorized parameter

    [n,~,qp1] = size(prior.mu); % Dimensions
    Theta = reshape(param_vec, n, n, qp1); % Reshape parameter vector into Theta matrix
    
    inds = sub2ind([n n], prior.norm_var, 1:n); % Linear indices of normalized IR coef's
    log_sigma = param_vec(inds); % Read log(sigma) values
    Theta(inds) = prior.mu(inds); % Substitute normalized coef's into Theta matrix
    Psi = bsxfun(@times, Theta, exp(log_sigma)); % Value of Psi under unit effect normalization (scale IRFs by sigma)

end