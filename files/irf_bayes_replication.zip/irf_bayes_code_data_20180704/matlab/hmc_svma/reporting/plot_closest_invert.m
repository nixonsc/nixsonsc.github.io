function [Theta_inv_draws, log_sigma_inv_draws] = plot_closest_invert(Theta_draws, log_sigma_draws, signif_level, plot_name, prior)

    % Plot closest invertible IRFs among parameters that are obs. equiv. to the draws
    
    [n, ~, ~, num_draws] = size(Theta_draws); % Dimensions
    inds = sub2ind([n n], prior.norm_var, 1:n); % Linear indices of normalized IR coef's
    
    Theta_inv_draws = zeros(size(Theta_draws)); % Will contain closest invertible IRFs
    log_sigma_inv_draws = zeros(size(log_sigma_draws)); % Will contain corresponding log(sigma) values
    
    disp('Computing closest invertible IRFs...');
    for k=1:num_draws; % For each draw...
        
        the_Psi = bsxfun(@times, Theta_draws(:,:,:,k), exp(log_sigma_draws(k,:))); % Compute Psi corresponding to (Theta,sigma)
        the_Psi_roots = flip_root_Psi(the_Psi); % Compute roots of Psi polynomial
        the_Psi_roots_flip = the_Psi_roots(imag(the_Psi_roots) >= 0 & abs(the_Psi_roots)<1); % Flip the roots smaller than 1 in abs. value (only one from each pair of complex conjugates)
        
        % Cycle through the roots and flip them
        the_Psi_inv = the_Psi;
        for m=1:length(the_Psi_roots_flip);
            [~, the_Psi_inv] = flip_root_Psi(the_Psi_inv, the_Psi_roots_flip(m));
        end;
        
        [the_Theta_inv, the_sigma_inv] = Psi_to_Theta(procrustes(the_Psi_inv, the_Psi), inds); % Find closest IRF and sigma values
        
        % Store computed values
        Theta_inv_draws(:,:,:,k) = the_Theta_inv;
        log_sigma_inv_draws(k,:) = log(the_sigma_inv);
        
        if mod(k, floor(num_draws/25)) == 0;
            fprintf('%1s', '.'); % Print progress
        end;
        
    end;
    disp(' ');
    
    
    % Plot invertible IRFs
    
    Theta_inv_means = mean(Theta_inv_draws, 4);
    Theta_inv_lower = quantile(Theta_inv_draws, signif_level/2, 4);
    Theta_inv_upper = quantile(Theta_inv_draws, 1-signif_level/2, 4);
    
    plot_tile( @(i,j) plot_irf(i, j, mean(Theta_draws, 4), [], [], Theta_inv_means, Theta_inv_lower, Theta_inv_upper, [], [], []), ...
               plot_name, prior); % Plot mean of Theta, along with mean and quantiles of invertible IRFs

end