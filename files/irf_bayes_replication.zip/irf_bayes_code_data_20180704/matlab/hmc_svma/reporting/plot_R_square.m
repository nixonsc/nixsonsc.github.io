function R_square_draws = plot_R_square(Theta_draws, log_sigma_draws, lags, plot_name, prior, R_square_draws_prior)

    % Posterior distribution of R-square in regression of shock on current and past data
    
    [n, ~, ~, num_draws] = size(Theta_draws);
    
    shock_filter_vars = zeros(num_draws, n);
    
    disp('Computing R-squares...');
    for k=1:num_draws;
        
        [~, the_shock_filter_var] = kf_svma(zeros(lags+1,n), bsxfun(@times, Theta_draws(:,:,:,k), exp(log_sigma_draws(k,:)))); % Run Kalman filter (on zero data, since I only care about conditional variance)
        shock_filter_vars(k,:) = diag(the_shock_filter_var);
        
        if mod(k, floor(num_draws/25)) == 0;
            fprintf('%1s', '.'); % Print progress
        end;
        
    end;
    disp(' ');
    
    R_square_draws = 1 - shock_filter_vars; % R-square values
    
    figure('Name', plot_name, 'Units', 'normalize', 'Position', [0.2 0.1 0.6 0.8]); % New figure
    
    for j=1:n; % For each shock...
        
        subtightplot(n, 1, j, [0.1 0.1], 0.07, 0.05); % New subplot
        histogram(R_square_draws(:,j), 'EdgeColor', 'none', 'FaceColor', 'b', 'Normalization', 'pdf'); % Histogram of R-square
        
        if ~isempty(R_square_draws_prior); % If prior draws are provided...
            hold on;
            [prior_dens_f, prior_dens_x]  = ksdensity(R_square_draws_prior(:,j)); % Kernel density estimate
            plot(prior_dens_x, prior_dens_f, '-r', 'LineWidth', 2); % Plot density estimate
            hold off;
        end;
            
        xlim([0 1]);
        set(gca,'FontSize', 12); % Adjust plot font size
        title(prior.shock_names{j}, 'FontSize', 16, 'FontWeight', 'bold');
        
    end;

end