function plot_shocks(Theta_draws, log_sigma_draws, signif_level, Y, time, prior)

    % Plot posterior mean of standardized shocks as well as posterior quantiles of absolute standardized shocks

    [T,n] = size(Y);
    num_draws = size(Theta_draws, 4); % Number of parameter draws
    
    shocks_smooth_means = zeros(T,n,num_draws); % Will contain conditional (smoothed) expectations of stand. shocks given parameter draw and data
    shocks_smooth_draws = zeros(T,n,num_draws); % Will contain draw of stand. shocks given parameter draw and data
    
    disp('Computing shocks...');
    for k=1:num_draws; % For each parameter draw
        
        [the_shocks_smooth_draw, the_shocks_smooth_mean] = sim_smoother(Y, Theta_draws(:,:,:,k), exp(log_sigma_draws(k,:))); % Run simulation smoother
        shocks_smooth_draws(:,:,k) = the_shocks_smooth_draw;
        shocks_smooth_means(:,:,k) = the_shocks_smooth_mean;
        
        if mod(k, floor(num_draws/25)) == 0;
            fprintf('%1s', '.'); % Print progress
        end;
        
    end;
    disp(' ');
    
    time_supplied = ~isempty(time); % Is vector of timestamps supplied?
    if ~time_supplied; % If not...
        time = 1:T; % Set timestamp equal to observation number
    end;
    
    
    % Posterior means of stand. shocks
    
    figure('Name', 'Posterior: mean of stand. shocks', 'Units', 'normalize', 'Position', [0.1 0.1 0.8 0.8]); % New figure
    
    for j=1:n; % For each shock...
        
        subtightplot(n, 1, j, [0.1 0.1], 0.07, 0.03); % New subplot
        plot(time, mean(shocks_smooth_means(:,j,:), 3), '-k', 'LineWidth', 2); % Posterior mean of stand. shocks over time
        if time_supplied;
            datetick('x', ' yy ');
        end;
        hold on;
        line([time(1) time(end)], [0 0], 'Color', 'k'); % Horizontal axis
        hold off;
        xlim([time(1) time(end)]);
        set(gca,'FontSize', 12); % Adjust plot font size
        title(prior.shock_names{j}, 'FontSize', 16, 'FontWeight', 'bold');
        
    end;
    
    
    % Posterior quantiles of absolute stand. shocks
    
    figure('Name', 'Posterior: quantiles of absolute stand. shocks', 'Units', 'normalize', 'Position', [0.1 0.1 0.8 0.8]); % New figure
    
    for j=1:n; % For each shock...
        
        subtightplot(n, 1, j, [0.1 0.1], 0.07, 0.03); % New subplot
        plot(time, median(abs(shocks_smooth_draws(:,j,:)), 3), '-k', 'LineWidth', 2); % Median
        hold on;
        plot(time, quantile(abs(permute(shocks_smooth_draws(:,j,:), [1 3 2])), [signif_level/2 1-signif_level/2], 2), '-k'); % Tail quantiles
        if time_supplied;
            datetick('x', ' yy ');
        end;
        line([time(1) time(end)], [0 0], 'Color', 'k'); % Horizontal axis
        hold off;
        xlim([time(1) time(end)]);
        set(gca,'FontSize', 12); % Adjust plot font size
        title(prior.shock_names{j}, 'FontSize', 16, 'FontWeight', 'bold');
        
        if j==n;
            legend({'Median', [num2str(signif_level/2, 2) ' quantile'], [num2str(1-signif_level/2, 2) ' quantile']}, 'Location', 'NorthEast', 'FontSize', 12); % Add legend to last plot
        end;
        
    end;

end