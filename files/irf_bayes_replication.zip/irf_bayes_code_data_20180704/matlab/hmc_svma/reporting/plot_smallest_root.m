function smallest_root_draws = plot_smallest_root(Theta_draws, Theta_true, plot_name, smallest_root_draws_prior)

    % Plot smallest MA roots of SVMA parameter draws

    num_draws = size(Theta_draws, 4);

    smallest_root_draws = zeros(num_draws,1);
    disp('Computing MA roots...');
    
    for k=1:num_draws; % For each draw...
        
        smallest_root_draws(k) = smallest_root(Theta_draws(:,:,:,k)); % Compute smallest root of MA polynomial corresponding to Theta
        
        if mod(k, floor(num_draws/25)) == 0;
            fprintf('%1s', '.'); % Print progress
        end;
        
    end;
    disp(' ');

    disp('Fraction of invertible draws');
    disp(mean(smallest_root_draws >= 1));

    figure('Name', plot_name, 'Units', 'normalize', 'Position', [0.1 0.2 0.8 0.6]); % New figure
    histogram(smallest_root_draws, 'EdgeColor', 'none', 'FaceColor', 'b', 'Normalization', 'pdf'); % Histogram of smallest roots
    the_ylim = ylim; % Save vertical axis limits
    
    hold on;
    line([1 1], the_ylim, 'Color', 'k', 'LineStyle', '--'); % Draw dashed vertical line at 1
    
    if ~isempty(Theta_true); % If true Theta value is supplied...
        smallest_root_true = smallest_root(Theta_true); % Compute smallest MA root for true Theta
        line(smallest_root_true*ones(1,2), the_ylim, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2); % Display it with thick vertical line
    end;
    
    if ~isempty(smallest_root_draws_prior); % If prior draws are provided...
        [prior_dens_f, prior_dens_x]  = ksdensity(smallest_root_draws_prior); % Kernel density estimate
        plot(prior_dens_x, prior_dens_f, '-r', 'LineWidth', 2); % Plot density estimate
    end;
    
    hold off;
    ylim(the_ylim); % Ensure vertical axis limits are preserved
    title('Histogram of smallest MA root');

end