function plot_pred_check(Y, Theta_draws, log_sigma_draws, check_fcts, check_fct_titles, plot_name, prior)

    % Plot prior/posterior predictive checks
    
    
    % Run check functions on data
    [T,n] = size(Y);
    output_data = check_fcts(Y);
    nf = size(output_data,2);
    
    
    % Run check functions on simulated data, mixing over the parameter draws
    num_draws = size(Theta_draws, 4);
    
    outputs = NaN(num_draws,n,nf);
    
    disp('Computing predictive checks...');
    for k=1:num_draws; % For each parameter draw...
        
        Y_sim = sim_svma(Theta_draws(:,:,:,k), exp(log_sigma_draws(k,:)), T); % Simulate data for given parameters
        outputs(k,:,:) = check_fcts(Y_sim); % Compute check functions on sim data
        
        if mod(k, floor(num_draws/25)) == 0;
            fprintf('%1s', '.'); % Print progress
        end;
        
    end;
    disp(' ');
    
    
    % Plot comparisons
    
    titles = cell(1,n); % Will contain title handles
    
    figure('Name', plot_name, 'Units', 'normalize', 'Position', [0.05 0.1 0.9 0.8]); % New figure
    
    for i=1:n; % For each variable...
        
        for f=1:nf; % For each check function...
                
            subtightplot(n, nf, nf*(i-1) + f, [0.07 0.07], 0.07, 0.07); % New subplot

            histogram(outputs(:,i,f), 'Normalization', 'probability'); % Histogram of posterior simulated values
            the_ylim = ylim;
            hold on;
            line(output_data(i,f)*ones(1,2), the_ylim, 'Color', 'k', 'LineWidth', 2); % Vertical line at data value
            hold off;
            ylim(the_ylim); % Enforce vertical axis limits
            set(gca,'FontSize', 12); % Adjust plot font size

            if i==1; % Write check function titles along columns
                title(check_fct_titles{f}, 'FontSize', 16, 'FontWeight', 'bold');
            end;
            
            if f==1; % Write variable names along rows
                titles{i} = ylabel(prior.var_names{i}, 'FontSize', 16, 'FontWeight', 'bold');
            end;
            
        end;
        
    end;
    
    align_var_labels(titles); % Align variable labels horizontally

end