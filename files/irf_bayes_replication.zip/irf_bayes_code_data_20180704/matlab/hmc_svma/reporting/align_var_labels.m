function align_var_labels(titles)

    % Align variable labels horizontally in plots

    n = length(titles);
    
    title_horz_pos = Inf; % Will contain left-most position of variable labels
    for i=1:n;
        set(titles{i}, 'Units', 'normalized'); % Measure position relative to figure, not data
        the_title_pos = get(titles{i}, 'Position'); % Position of label
        title_horz_pos = min(title_horz_pos, the_title_pos(1)); % Update left-most position of variable labels
    end;
    
    for i=1:n;
        the_title_pos = get(titles{i}, 'Position');
        set(titles{i}, 'Position', [title_horz_pos the_title_pos(2)]); % Align horizontally
    end;

end