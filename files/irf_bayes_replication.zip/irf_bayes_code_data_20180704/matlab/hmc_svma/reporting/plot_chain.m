function plot_chain(i, j, draws, nuts)

    % Plot MCMC chain

    burnin = nuts.burnin;
    store_every = nuts.store_every;

    num_stored_draws = size(draws, 4); % Number of stored draws

    plot((1:num_stored_draws) * store_every, squeeze(draws(i,j,:,:))); % Plot chain for each impulse response coefficient corresponding to variable i and shock j
    the_ylim = ylim;
    line(burnin * ones(1,2), the_ylim, 'Color', 'k', 'LineStyle', '--'); % Mark burn-in time with vertical line
    ylim(the_ylim);

end