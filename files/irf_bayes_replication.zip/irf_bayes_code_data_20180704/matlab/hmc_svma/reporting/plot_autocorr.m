function autocorr_draws = plot_autocorr(Theta_draws, log_sigma_draws, signif_level, plot_name, prior, varargin)

    % Compute and plot draws of autocorrelation function

    Psi_draws = bsxfun(@times, Theta_draws, permute(exp(log_sigma_draws), [3 2 4 1])); % Draws of Psi
    
    num_draws = size(Psi_draws, 4);
    
    autocorr_draws = zeros(size(Psi_draws));
    disp('Computing autocorrelations...');
    
    for k=1:num_draws; % For each draw...
        
        the_acf = acf_svma(Psi_draws(:,:,:,k)); % Implied autocovariance function
        the_sd = sqrt(diag(the_acf(:,:,1))); % Implied std. dev. of each variable
        autocorr_draws(:,:,:,k) = bsxfun(@rdivide, the_acf, the_sd*the_sd'); % Implied autocorrelation function
        
        if mod(k, floor(num_draws/25)) == 0;
            fprintf('%1s', '.'); % Print progress
        end;
        
    end;
    disp(' ');
    
    means = mean(autocorr_draws, 4);
    lower = quantile(autocorr_draws, signif_level/2, 4);
    upper = quantile(autocorr_draws, 1-signif_level/2, 4);
    
    prior_copy = prior;
    prior_copy.shock_names = prior.var_names; % Replace shock names with variable names in prior to get the plot labels right
    
    prior_means = [];
    prior_lower = [];
    prior_upper = [];
    truth = [];
    
    if ~isempty(varargin); % If prior draws are provided...
        
        autocorr_draws_prior = varargin{1}; % Prior draws
        
        % Compute means and percentile bands for prior draws
        prior_means = mean(autocorr_draws_prior, 4);
        prior_lower = quantile(autocorr_draws_prior, signif_level/2, 4);
        prior_upper = quantile(autocorr_draws_prior, 1-signif_level/2, 4);
        
        if ~isempty(varargin{2}); % If true Theta and sigma are also supplied...
            
            Psi_true = bsxfun(@times, varargin{2}, varargin{3}); % True Psi
            acf_true = acf_svma(Psi_true); % True ACF
            sd_true = sqrt(diag(acf_true(:,:,1))); % True std. dev. of variables
            truth = bsxfun(@rdivide, acf_true, sd_true*sd_true'); % True autocorrelation function
            
        end;
        
    end;
    
    plot_tile( @(i,j) plot_irf(i, j, truth, prior_lower, prior_upper, means, lower, upper, prior_means, {[0 0 1]}, [], '--'), plot_name, prior_copy); % Plot means and percentile bands

end