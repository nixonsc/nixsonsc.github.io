clear;

% ****************************************
% *** Identification and invertibility ***
% *** Univariate example               ***
% *** MPM, 2015-10-03                  ***
% ****************************************


% *** SETTINGS

irf = [1 1.5 2.7 1.2 0.3]; % Initial IRF in identified set
plot_num = 4; % Plot this many IRFs that are observationally equivalent with "irf" (including "irf"), sorted from highest sigma to lowest
line_colors = {[0 0 0], [1 0 0], [0 0 1], [0.2 0.7 0], [0.9 0.5 0], [0.4 0.4 0.4], [0.7 0 0.7], [0 0.7 0.7]}; % Colors of lines in IRF plot
line_styles = {'-', '-', '--', '-.'}; % Line styles of IRFs in plot
plot_irf_ylim = [0 15]; % Vertical axis limits in IRF plot (if empty, revert to default)
plot_legend = 1; % =1: Add legend with sigma values to plot

% *** END SETTINGS


addpath(fullfile('.', 'identif_set'), fullfile('.', 'nuts'), fullfile('.', 'reporting')); % Add paths for auxiliary files

q = length(irf)-1; %MA lag length
irf_norm = irf/sqrt(irf*irf'); % Normalize so that ACF has Gamma(0)=1
acf = permute(acf_svma(permute(irf_norm, [1 3 2])), [1 3 2]);  % ACF corresponding to initial IRF

% Obtain rough estimate of Wold representation from innovations algorithm
[B,V] = innovations_algorithm(permute(acf, [1 3 2]));
Psi_init = [1 squeeze(B)']*sqrt(V);

% Numerically solve for Wold representation
f = @(x) acf' - squeeze(acf_svma(permute(x, [3 1 2]))); % Function to set to zero
opts = optimset('Display', 'iter');
Psi_wold = fsolve(f, Psi_init, opts); % Solve for Wold representation (first coefficient is not normalized to 1)

Psi_roots = flip_root_Psi(permute(Psi_wold, [3 1 2])); % Roots of Wold polynomial
Psi_roots_trim = Psi_roots(imag(Psi_roots)>=0); % Only keep one root from each complex conjugate pair
num_roots = length(Psi_roots_trim); % Number of roots

disp('Roots');
disp(Psi_roots_trim);

disp('Abs. val. of roots');
disp(abs(Psi_roots_trim));

Psis = zeros(2^num_roots, q+1); % Will contain all Psi polynomials consistent with the ACF
Psis(1,:) = Psi_wold; % First polynomial: Wold (invertible)

for k=1:2^num_roots-1; % Cycle through root flip possibility, of which there are 2^num_roots
    
    root_inds_to_flip_str = dec2bin(k); % Binary reprsentation of k
    root_inds_to_flip_str = sprintf(['%0' num2str(num_roots) 'd'], str2num(root_inds_to_flip_str)); % Pad with zeros
    
    % Determine which roots to flip
    root_inds_to_flip = zeros(1,num_roots);
    for m=1:num_roots;
        root_inds_to_flip(m) = strcmp(root_inds_to_flip_str(m), '1');
    end;
    roots_to_flip = Psi_roots_trim(root_inds_to_flip == 1); % List of roots to flip
    
    % Flip the roots one by one
    the_Psi = permute(Psi_wold, [3 1 2]); % Start with Wold polynomial
    for m=1:length(roots_to_flip);
        [~, the_Psi] = flip_root_Psi(the_Psi, roots_to_flip(m)); % Flip root
    end;
    
    Psis(k+1,:) = squeeze(the_Psi)'; % Save flipped polynomial
    
end;

% Record corresponding sigmas and Thetas
sigmas = abs(Psis(:,1));
[sigmas, sort_ind] = sort(sigmas, 'descend');
Psis = Psis(sort_ind,:);
Thetas = bsxfun(@times, Psis, sign(Psis(:,1))./sigmas);

disp('Sigmas');
disp(sigmas);

disp('Thetas');
disp(Thetas);

% Figure
figure('Units', 'normalize', 'Position', [0.1 0.2 0.7 0.5]);

subtightplot(1, 2, 1, [0.1 0.05], 0.08, 0.05); % Subplot with ACF
plot(0:q, acf, '-ko', 'LineWidth', 2);
hold on;
the_xlim = xlim;
line(the_xlim, [0 0], 'Color', 'k'); % Horizontal axis
hold off;
set(gca, 'XTick', 0:q);
the_ylim = ylim;
ylim([min(0,the_ylim(1)) min(1,the_ylim(2))]);
set(gca,'FontSize', 12); % Adjust plot font size
title('Autocovariance function', 'FontSize', 16);

subtightplot(1, 2, 2, [0.1 0.05], 0.08, 0.05); % Subplot with IRFs
plot(0:q, Thetas(1,:), '-o', 'LineWidth', 2, 'Color', line_colors{1});
hold on;
for k=2:min(2^num_roots, plot_num); % For each IRF to plot...
    plot(0:q, Thetas(k,:), [line_styles{k} 'o'], 'LineWidth', 1, 'Color', line_colors{k}); % Plot IRF with correct line style and color
end;
the_xlim = xlim;
line(the_xlim, [0 0], 'Color', 'k'); % Horizontal axis
hold off;
set(gca, 'XTick', 0:q);
if ~isempty(plot_irf_ylim);
    ylim(plot_irf_ylim);
else
    ylim([min(0,the_ylim(1)) ceil(the_ylim(2))]);
end;
set(gca,'FontSize', 12); % Adjust plot font size
title('Observationally equivalent IRFs', 'FontSize', 16);

if plot_legend == 1;
    
    % Add legend
    the_legend = cell(1,min(2^num_roots, plot_num));
    for k=1:length(the_legend);
        the_legend{k} = ['\sigma=' sprintf('%4.2f', sigmas(k))];
        if k == 1 ;
            the_legend{1} = [the_legend{1} ' invert.'];
        else
            the_legend{k} = [the_legend{k} ' noninv.'];
        end;
    end;
    
    legend(the_legend, 'FontSize', 12, 'Location', 'NorthWest');

end;