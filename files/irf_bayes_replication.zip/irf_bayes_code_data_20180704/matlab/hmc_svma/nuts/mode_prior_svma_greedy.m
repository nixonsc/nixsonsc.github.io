function [Theta_mode, sigma_mode, Psi_mode, log_prior] = mode_prior_svma_greedy(Psi, prior)

    % Greedily flip roots of SVMA polynomial to improve value of prior density
    

    n = size(Psi,1);
    inds = sub2ind([n n], prior.norm_var, 1:n); % Linear indices of normalized IR coef's

    Psi_roots = flip_root_Psi(Psi, []); % Roots of Psi polynomial
    Psi_roots_trim = Psi_roots(imag(Psi_roots) >= 0); % Only keep one from each pair of complex roots (and keep all real roots)
    num_roots = length(Psi_roots_trim); % Number of roots
    
    prior_mean_Psi = bsxfun(@times, prior.mu, exp(prior.mu_sigma + 0.5*prior.tau_sigma.^2)); % Prior mean of Psi
    
    unflipped_roots = 0:num_roots; % List of roots that haven't been flipped yet
    Psi_mode = Psi;
    [Theta_mode, sigma_mode] = Psi_to_Theta(Psi, inds);
    log_prior = -inf;
    
    k_new = 0;
    
    while k_new >= 0; % While we can still improve prior density by flipping a root...
        
        Psi_mode_new = Psi_mode;
        Theta_mode_new = Theta_mode;
        sigma_mode_new = sigma_mode;
        log_prior_new = log_prior;
        k_new = -1;
    
        for k=unflipped_roots; % For each root that hasn't been flipped yet...

            if k == 0; % Don't flip any roots
                the_Psi = Psi_mode;
            else % Flip one root
                [~, the_Psi] = flip_root_Psi(Psi_mode, Psi_roots_trim(k)); % Flip root (and its complex conjugate if complex)
            end;

            the_Psi_rotated = procrustes(the_Psi, prior_mean_Psi); % Rotate Psi polynomial
            [the_Theta, the_sigma] = Psi_to_Theta(the_Psi_rotated, inds); % Corresponding Theta and sigma values

            the_log_prior = prior_svma(prior, the_Theta, log(the_sigma), []); % Log prior at (Theta,sigma)

            if the_log_prior > log_prior_new + eps^(1/2); % If log prior is improved relative to previous best...

                Psi_mode_new = the_Psi_rotated;
                Theta_mode_new = the_Theta;
                sigma_mode_new = the_sigma;
                log_prior_new = the_log_prior;
                k_new = k; % Root that was flipped

            end;

        end;
        
        if k_new >= 0; % If prior density was improved by some root flip...
            
            Psi_mode = Psi_mode_new;
            Theta_mode = Theta_mode_new;
            sigma_mode = sigma_mode_new;
            log_prior = log_prior_new;
            unflipped_roots = unflipped_roots(unflipped_roots ~= k_new); % Remove the newly flipped root from list of roots to flip
            
            % Display the flipped root
            if k_new == 0;
                disp('No root flip');
            else
                disp(['Flipped root: ' num2str(Psi_roots_trim(k_new))]);
            end;
            
        end;
    
    end;

end