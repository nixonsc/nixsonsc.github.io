function the_acf = acf_data(Y, max_lag)

    % Compute ACF of data
    
    [T,n] = size(Y); % Dimensions
    
    the_acf = zeros(n, n, max_lag);
    for l=0:max_lag;
        the_acf(:,:,l+1) = (Y(l+1:end,:)'*Y(1:end-l,:))/T;
    end;

end