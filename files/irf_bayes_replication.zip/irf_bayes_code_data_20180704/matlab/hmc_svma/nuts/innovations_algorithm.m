function [B, V] = innovations_algorithm(acf)

    % Multivariate innovations algorithm (Brockwell & David, 1991, Prop. 11.4.2)

    
    % Dimensions
    [n, ~, qp1] = size(acf);
    q = qp1 - 1;
    
    Bs = zeros(n, n, q, q+1);
    Vs = zeros(n, n, q+1);
    Vs(:,:,1) = acf(:,:,1);
    
    for t=1:q; % Run through first q time steps
        
        Bs(:,:,:,2:end) = Bs(:,:,:,1:end-1);
        Vs(:,:,2:end) = Vs(:,:,1:end-1);
        
        for l = min(q,t):-1:1;
            
            Bs(:,:,l,1) = acf(:,:,l+1);
            for j = l+1:min(q,t);
                Bs(:,:,l,1) = Bs(:,:,l,1) - Bs(:,:,j,1)*Vs(:,:,j+1)*Bs(:,:,j-l,l+1)';
            end;
            Bs(:,:,l,1) = Bs(:,:,l,1)/Vs(:,:,l+1);
            
        end;
        
        Vs(:,:,1) = acf(:,:,1);
        for j = 1:min(q,t);
            Vs(:,:,1) = Vs(:,:,1) - Bs(:,:,j,1)*Vs(:,:,j+1)*Bs(:,:,j,1)';
        end;
        
    end;
    
    B = Bs(:,:,:,1);
    V = Vs(:,:,1);

end