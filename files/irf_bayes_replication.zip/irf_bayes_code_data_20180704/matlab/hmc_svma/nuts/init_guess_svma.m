function [param_vec_init, Theta_mode, sigma_mode, acf] = init_guess_svma(Y, Y_tilde, prior)

    % Compute approximate posterior mode

    % Dimensions
    [n, ~, qp1] = size(prior.mu);

    % Compute ACF of data
    acf = acf_data(Y, qp1-1);

    % Run innovations algorithm to obtain invertible SVMA representation that approximately fits the data
    [B, V] = innovations_algorithm(acf);
    B_pad = zeros(n, n, qp1);
    B_pad(:,:,1) = eye(n);
    B_pad(:,:,2:end) = B;
    Psi = rotate_Psi(B_pad, chol(V));

    [Theta_mode, sigma_mode] = mode_prior_svma_greedy(Psi, prior); % Flip roots of SVMA representation to maximize prior among SVMA representations with same ACF
    
    param_vec_mode = Theta_mode(:)'; % Initial posterior mode estimate, vectorized
    param_vec_mean = prior.mu(:)'; % Prior mean, vectorized
    
    inds = sub2ind([n n], prior.norm_var, 1:n); % Linear indices of normalized IR coef's
    param_vec_mode(inds) = log(sigma_mode);
    param_vec_mean(inds) = prior.mu_sigma + 0.5*prior.tau_sigma.^2;
    
    param_vec_init = [];
    logpost = -Inf;
    shrinkage = [];
    
    % Search through convex combinations of initial posterior mode estimate and prior mean
    for x = 0:0.01:1;
        
        the_param_vec = (1-x)*param_vec_mode + x*param_vec_mean; % Convex combination
        the_logpost = logpost_vec(Y_tilde, prior, the_param_vec); % Log posterior at convex combination
        
        if the_logpost > logpost; % If log posterior is improved...
            
            param_vec_init = the_param_vec; % New estimate of posterior mode
            logpost = the_logpost;
            shrinkage = x;
            
        end;
        
    end;
    
    disp(['Optimal shrinkage: ' num2str(shrinkage)]);

end