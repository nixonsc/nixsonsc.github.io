function [Y, SVMA_model, shocks] = sim_svma(Theta, sigma, T, varargin)

    % Simulate data from SVMA model
    
    [n,~,qp1] = size(Theta);
    
    Theta_cell = num2cell(Theta, [1 2]); % Convert MA coefficient matrices into cell array
    SVMA_model = vgxset('n', n, 'MA0', Theta_cell{1}, 'MA', Theta_cell(2:end), 'Q', diag(sigma.^2)); % Specify SVMA model
    
    if ~isempty(varargin); % If prior struct is supplied as an argument...
        prior = varargin{1};
        SVMA_model = vgxset(SVMA_model, 'Series', prior.var_names); % Define series names
    end;
    
    [Y, shocks] = vgxsim(SVMA_model, T, [], [], bsxfun(@times, randn(qp1-1,n), sigma)); % Simulate SVMA data (with nonzero pre-sample shocks)
    
end