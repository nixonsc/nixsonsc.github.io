function [shocks_smooth_draw, shocks_smooth_mean_data] = sim_smoother(Y, Theta, sigma)

    % Simulation smoother (Durbin and Koopman, 2002)
    % See Durbin and Koopman 2012 textbook (2nd ed.), Chapter 4.9

    T = size(Y,1); % Sample size

    Phi = bsxfun(@times, Theta, sigma); % Scaled IRFs
    [~, ~, shocks_smooth_mean_data] = kf_svma(Y, Phi); % Expectation of standardized shocks given data and parameters
    
    [Y_sim, ~, shocks_sim] = sim_svma(Theta, sigma, T); % Simulated data and stand. shocks given parameters
    [~, ~, shocks_smooth_mean_sim] = kf_svma(Y_sim, Phi); % Expectation of stand. shocks given simulated data and parameters
    
    shocks_smooth_draw = shocks_sim - shocks_smooth_mean_sim + shocks_smooth_mean_data; % Draw from posterior distribution of stand. shocks given data and parameters

end