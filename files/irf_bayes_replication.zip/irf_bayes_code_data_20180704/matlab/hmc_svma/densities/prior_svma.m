function [log_prior, grad_Theta, grad_log_sigma, sim_Theta, sim_log_sigma] = prior_svma(prior, Theta, log_sigma, num_sim)

    n = size(prior.mu,1); % Number of variables/shocks
    qp1 = size(prior.mu,3); % Number of prior lags plus one
    
    log_prior = 0; % Initialize log prior
    
    grad_Theta = zeros(n, n, qp1); % Will contain gradient wrt. Theta
    sim_Theta = nan(n, n, qp1, num_sim); % Will contain simulated Theta values
    
    for i=1:n; % For each response variable...
        
        for j=1:n; % For each shock...
            
            V = prior_varblock(i, j, prior); % Var-cov matrix of IRF
            
            if ~isempty(Theta); % If parameter value has been supplied...
                
                a = squeeze(Theta(i,j,:) - prior.mu(i,j,:)); % Note: This is zero for the normalized coef's, so these don't contribute to log prior
                the_grad = -V\a;
                log_prior = log_prior + 0.5*a'*the_grad; % Contribution to log prior
                grad_Theta(i,j,:) = the_grad; % Gradient
                
            else % Otherwise, simulate
                
                sim_Theta(i, j, :, :) = mvnrnd(squeeze(prior.mu(i,j,:)), V, num_sim)'; % Multivariate normal
                
                if prior.norm_var(j) == i; % If initial response is normalized...
                    sim_Theta(i, j, 1, :) = repmat(prior.mu(i,j,1), num_sim, 1); % Replace simulated initial coef's with normalized coef
                end;
                
            end;
            
        end;
        
    end;
    
    grad_log_sigma = []; % Will contain gradient wrt. log(sigma)
    sim_log_sigma = []; % Will contain simulated log(sigma) values
    
    if ~isempty(log_sigma); % If parameter value has been supplied...

        a = log_sigma - prior.mu_sigma;
        grad_log_sigma = -a./(prior.tau_sigma.^2); % Gradient
        log_prior = log_prior + 0.5*grad_log_sigma*a'; % Contribution to log prior

    else % Otherwise, simulate

        sim_log_sigma = bsxfun(@plus, bsxfun(@times, randn(num_sim,n), prior.tau_sigma), prior.mu_sigma);

    end;

end