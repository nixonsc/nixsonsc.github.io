function [logpost, grad] = logpost_vec(Y_tilde, prior, param_vec)

    % Log posterior and its gradient for vectorized parameter
    
    [Psi, Theta, log_sigma, inds] = reparam_vec(prior, param_vec); % Obtain Psi, Theta and log(sigma) from vectorized parameter
    
    grad = [];
    
    if nargout > 1; % If gradient is desired...
        
        [ll, ll_grad_Psi] = whittle_svma(Y_tilde, Psi); % Log likelihood and gradient wrt. Psi
        [lp, lp_grad_Theta, lp_grad_log_sigma] = prior_svma(prior, Theta, log_sigma, []); % Log posterior and gradients wrt. Theta and log(sigma)
        
        lp_grad = lp_grad_Theta; % Log prior gradient wrt. parameter vector under unit standard deviation parametrization
        
        lp_grad(inds) = lp_grad_log_sigma; % Substitute log prior gradient wrt. log(sigma)

        ll_grad = bsxfun(@times, ll_grad_Psi, exp(log_sigma)); % Log likelihood gradient wrt. Theta
        ll_grad(inds) = sum(sum(ll_grad_Psi .* Psi, 3), 1); % Substitute log likelihood gradient wrt. log(sigma)
        
        grad = ll_grad + lp_grad; % Gradient of log posterior
        
    else % If only log posterior is desired...
        
        ll = whittle_svma(Y_tilde, Psi);
        lp = prior_svma(prior, Theta, log_sigma, []);
        
    end;
    
    logpost = ll + lp; % Log posterior
    grad = grad(:)'; % Gradient of log posterior, vectorized

end