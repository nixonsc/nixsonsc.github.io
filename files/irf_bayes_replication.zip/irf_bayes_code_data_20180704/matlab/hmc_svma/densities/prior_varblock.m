function V = prior_varblock(i, j, prior)

    % Return prior var-cov matrix for IRF (i,j)

    qp1 = size(prior.mu, 3);
    toepl = toeplitz(0:qp1-1); % Toeplitz matrix for calculating prior covariance matrix

    tau_vec = permute(prior.tau(i,j,:), [3 1 2]); % Vector of prior std. dev. for IRF (i,j)
    V = (tau_vec*tau_vec') .* (prior.rho(i,j) .^ toepl); % Prior covariance matrix for IRF (i,j)
    
    if prior.norm_var(j) == i; % If initial response is normalized...
        V = blkdiag(1, V(2:end,2:end)); % Block diagonal prior covariance matrix (the (1,1) element is arbitrarily set to 1 - it won't get used in calculations)
    end;

end