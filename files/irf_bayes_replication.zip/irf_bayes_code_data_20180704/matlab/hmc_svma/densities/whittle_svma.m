function [wll, grad] = whittle_svma(Y_tilde, Psi)
    
    % Calculate Whittle log likelihood and its gradient
    % Note: DFT of data uses different scaling convention than in paper
    
    T = size(Y_tilde, 1); % Sample size
    n = size(Psi, 1); % Data dimension
    T_mid = floor(T/2); % Mid point of sample
    T_even = 1-mod(T,2); % Indicator for even sample size
    
    Psi_tilde = fft(Psi, T, 3); % FFT of Psi
    
    wll = 0; % Initialize log likelihood
    C = zeros(n,n,T); % Initialize C matrix
    
    for k=1:T_mid+1; % For Fourier frequencies 0,1,...,T_mid
        
        f_k = Psi_tilde(:,:,k)*Psi_tilde(:,:,k)'; % Outer product of FFT of Psi
        aux_j = f_k\(Y_tilde(k,:).');
        wll = wll - 0.5*(2 - (k==1 || (T_even==1 && k==T_mid+1)))*real( log(det(f_k)) + conj(Y_tilde(k,:))*aux_j ) ; % Contribution to Whittle log likelihood (adjust for frequency 0, and sample mid point if T even)
        
        if nargout > 1;
            
            C(:,:,k) = eye(n)/f_k - aux_j*aux_j'; % C matrix for use when calculating derivative
            
        end;
        
    end;
    
    if nargout > 1; % If gradient is requested...
        
        C(:,:,T_mid+2:T) = conj(C(:,:,T_mid+1-T_even:-1:2)); % Fill in rest of C matrix based on periodicity of FFT
        
        q = size(Psi,3)-1; % MA leg length
        C_tilde = fft(C, [], 3); % FFT of C
        C_tilde_double_real = real(cat(3, C_tilde, C_tilde)); % Duplicate FFT of C
        Psi_vertical = reshape(permute(Psi, [1 3 2]), n*(q+1), n); % Stack Psi_l matrices on top of each other
        
        grad = zeros(n, n, q+1); % Initialize gradient
        
        for j=0:q;
            
            grad(:,:,j+1) = -reshape(C_tilde_double_real(:,:,T+1-j:T+1+q-j), n, n*(q+1)) * Psi_vertical; % Gradient wrt. Psi_j
            
        end;
        
    end;

end