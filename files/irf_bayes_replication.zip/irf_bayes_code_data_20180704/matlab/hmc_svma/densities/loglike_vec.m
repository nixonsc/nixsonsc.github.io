function [mll, mgrad] = loglike_vec(Y_tilde, param_vec)

    % Minus Whittle log likelihood as function of vec(Theta)
    
    n = size(Y_tilde,2);
    
    [ll, grad] = whittle_svma(Y_tilde, reshape(param_vec, n, n, [])); % Log likelihood and gradient wrt. Psi
    
    mll = -ll; % Minus log likelihood
    mgrad = -grad(:)'; % Vectorize gradient of minus log likelihood

end