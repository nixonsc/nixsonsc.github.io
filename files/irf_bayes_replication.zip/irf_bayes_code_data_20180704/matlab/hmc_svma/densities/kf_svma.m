function [L, shock_filter_var, shocks_smooth_mean] = kf_svma(Y, Psi)

    % Kalman filter, smoother and log likelihood for SVMA model
    % Computed by efficient univariate treatment, cf. Durbin and Koopman (2012), Chapter 6.4
    % MPM, 2015-05-13, 2015-08-28
    
    
    tol = eps^(2/3); % Tolerance for deciding whether forecast error variance is numerically zero
    
    % Dimensions
    [T,n] = size(Y);
    qp1 = size(Psi,3);
    
    Psi_horz = reshape(Psi, n, n*qp1); % Psi parameter vector, horizontal version
    
    a = zeros(n*qp1,1); % Initialize filtered estimate of state
    Z = eye(n*qp1); % Initialize filter variance
    L = 0; % Initialize log likelihood
    
    if nargout > 2; % If smoothed standardized shocks should be outputted...
        
        norm_v_store = zeros(T,n); % Will contain v_{t,i}/lambda_{t,i}
        g_store = zeros(n*qp1,T,n); % Will contain Kalman gains
        
    end;
    
    for t=1:T; % For each time period...
        
        for i=1:n; % Run through observed variables one by one
            
            v = Y(t,i) - Psi_horz(i,:)*a; % Forecast error
            aux = Z*Psi_horz(i,:)';
            lambda = Psi_horz(i,:)*aux; % Forecast variance
            
            if lambda > tol; % If forecast error variance is non-negligible
                
                L = L - 0.5*(log(lambda) + v*v/lambda); % Contribution to log likelihood
                
                g = aux/lambda; % Kalman gain
                a = a + g*v; % Update filtered estimate of state
                Z = Z - (g*g')*lambda; % Update filter variance
                
                if nargout > 2; % If smoothing recursion should be run below, store some of the filter output
                
                    norm_v_store(t,i) = v/lambda;
                    g_store(:,t,i) = g;
                
                end;
                
            else
                
                warning('Near-zero forecast error variance in Kalman filter');
                
            end;
            
        end;
        
        shock_filter_var = Z(1:n,1:n); % Var(tilde{epsilon}_t | y_t, ..., y_1, Psi)
        
        % Transition to next time point: tilde{epsilon}_{t-q} removed from bottom of state vector, tilde{epsilon}_{t+1} added at top of state vector
        a = [zeros(n,1); a(1:end-n)];
        Z = blkdiag(eye(n), Z(1:end-n,1:end-n));
        
    end;
    
    if nargout > 2; % If smoothed standardized shocks are desired...
        
        shocks_smooth_mean = zeros(T,n);
        r = zeros(n*qp1,1); % r_{t,i} in the notation of Durbin and Koopman (2012)
        
        for t=T:-1:1; % Running backwards in time...
            
            for i=n:-1:1; % And cycling backwards through the variables...
                
                r = r + Psi_horz(i,:)'*(norm_v_store(t,i) - g_store(:,t,i)'*r); % Update r_{t,i} vector recursively
                
            end;
            
            shocks_smooth_mean(t,:) = r(1:n); % Store posterior mean for standardized shock tilde{epsilon}_t
            r = [r(n+1:end); zeros(n,1)]; % Move to next time point
            
        end;
        
    end;

end