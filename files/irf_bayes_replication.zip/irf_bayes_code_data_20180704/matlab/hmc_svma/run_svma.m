clear;

% **********************************
% *** Simulation of and Bayesian ***
% *** inference in SVMA model    ***
% *** MPM, 2015-02-25            ***
% **********************************


% *** SETTINGS

% Choose application number:
% 1: Bivariate simulation example, baseline
% 2: Bivariate simulation example, rho=0.3
% 3: Bivariate simulation example, misspecified prior: persistence
% 4: Bivariate simulation example, misspecified prior: cross-correlation
% 5: Bivariate simulation example, misspecified prior: persistence and cross-correlation
% 6: Bivariate simulation example, misspecified prior: root flip
% 7: News shock empirical application, real data
% 8: News shock empirical application, real data, larger prior variance
% 9: News shock empirical application, simulated data
application_num = 1;

switch application_num;
    
    case 1; % Bivariate simulation example, baseline
        prior_filename = 'prior_bivariate'; % .m file that specifies prior structure
        data_filename = 'data_bivariate'; % .m file that loads data vector Y (and optionally specifies Theta_true and/or sigma_true)
        settings_filename = 'settings_bivariate'; % .m file that specifies MCMC settings structure
        results_filename = 'results/bivariate_20150916'; % .mat file name for storing or loading (will load results from here if run_NUTS=0)
        
    case 2; % Bivariate simulation example, rho=0.3
        prior_filename = 'prior_bivariate_rho03'; % .m file that specifies prior structure
        data_filename = 'data_bivariate'; % .m file that loads data vector Y (and optionally specifies Theta_true and/or sigma_true)
        settings_filename = 'settings_bivariate'; % .m file that specifies MCMC settings structure
        results_filename = 'results/bivariate_rho03_20150916'; % .mat file name for storing or loading (will load results from here if run_NUTS=0)
        
    case 3; % Bivariate simulation example, misspecified prior: persistence
        prior_filename = 'prior_bivariate'; % .m file that specifies prior structure
        data_filename = 'data_bivariate_pers'; % .m file that loads data vector Y (and optionally specifies Theta_true and/or sigma_true)
        settings_filename = 'settings_bivariate'; % .m file that specifies MCMC settings structure
        results_filename = 'results/bivariate_pers_20150930'; % .mat file name for storing or loading (will load results from here if run_NUTS=0)
    
    case 4; % Bivariate simulation example, misspecified prior: cross-correlation
        prior_filename = 'prior_bivariate'; % .m file that specifies prior structure
        data_filename = 'data_bivariate_corr'; % .m file that loads data vector Y (and optionally specifies Theta_true and/or sigma_true)
        settings_filename = 'settings_bivariate'; % .m file that specifies MCMC settings structure
        results_filename = 'results/bivariate_corr_20150930'; % .mat file name for storing or loading (will load results from here if run_NUTS=0)
        
    case 5; % Bivariate simulation example, misspecified prior: persistence and cross-correlation
        prior_filename = 'prior_bivariate_perscorr'; % .m file that specifies prior structure
        data_filename = 'data_bivariate_perscorr'; % .m file that loads data vector Y (and optionally specifies Theta_true and/or sigma_true)
        settings_filename = 'settings_bivariate'; % .m file that specifies MCMC settings structure
        results_filename = 'results/bivariate_perscorr_20170614'; % .mat file name for storing or loading (will load results from here if run_NUTS=0)
    
    case 6; % Bivariate simulation example, misspecified prior: root flip
        prior_filename = 'prior_bivariate'; % .m file that specifies prior structure
        data_filename = 'data_bivariate_flip'; % .m file that loads data vector Y (and optionally specifies Theta_true and/or sigma_true)
        settings_filename = 'settings_bivariate'; % .m file that specifies MCMC settings structure
        results_filename = 'results/bivariate_flip_20170613'; % .mat file name for storing or loading (will load results from here if run_NUTS=0)
        
    case 7; % News shock empirical application, real data
        prior_filename = 'prior_news'; % .m file that specifies prior structure
        data_filename = 'data_news_dat'; % .m file that loads data vector Y (and optionally specifies Theta_true and/or sigma_true)
        settings_filename = 'settings_news_dat'; % .m file that specifies MCMC settings structure
        results_filename = 'results/news_dat_20150915'; % .mat file name for storing or loading (will load results from here if run_NUTS=0)
        
    case 8; % News shock empirical application, real data, larger prior variance
        prior_filename = 'prior_news_alt'; % .m file that specifies prior structure
        data_filename = 'data_news_dat'; % .m file that loads data vector Y (and optionally specifies Theta_true and/or sigma_true)
        settings_filename = 'settings_news_dat_alt'; % .m file that specifies MCMC settings structure
        results_filename = 'results/news_dat_alt_20170613'; % .mat file name for storing or loading (will load results from here if run_NUTS=0)
        
    case 9; % News shock empirical application, simulated data
        prior_filename = 'prior_news'; % .m file that specifies prior structure
        data_filename = 'data_news_sim'; % .m file that loads data vector Y (and optionally specifies Theta_true and/or sigma_true)
        settings_filename = 'settings_news_dat'; % .m file that specifies MCMC settings structure
        results_filename = 'results/news_sim_20150915'; % .mat file name for storing or loading (will load results from here if run_NUTS=0)
        
end;

% Decide what to do
plot_prior = 0; % Plot prior
load_data = 0; % Load and plot data
run_nuts = 0; % Run NUTS algorithm
results_store = 0; % Store results in .mat file (if NUTS has been run)
results_show = 1; % Show results (if NUTS hasn't been run, the code will try to load stored results)

% Prior plot settings (require plot_prior=1)
plot_prior_draws = 4; % Number of prior IRF draws to plot
plot_prior_colors = {[1 0 0], [0.2 0.7 0], [0.9 0.5 0], [0 0 1]}; % Colors for draws
plot_prior_mean = 0; % =1: produce plot that only contains prior means
plot_prior_extra = 0; % =1: report prior FEVD, long-run IRs, and autocorrelations
plot_prior_inv = 0; % =1: report prior probability of invertibility, histogram of smallest MA root, and R-square values
plot_prior_pred = 0; % =1: report prior predictive checks (requires load_data=1)
plot_prior_comp_draws = 1e4; % Number of draws for calculating various features of the prior distribution

% Data/HMC plot settings (require load_data=1 or run_nuts=1)
plot_data = 0; % Plot data (both raw, trend and cycle, if applicable) and autocorrelation function of detrended data
plot_ic = 0; % Plot information criteria for q (WARNING: may take a long time to run)
plot_truth = 0; % Plot true value of IRFs (if applicable)
plot_init_draw = 0; % Plot initial value for NUTS algorithm and DO NOT run the rest of the algorithm
plot_data_autocorr_lag = 30; % Maximum lag for autocorrelation plot

% Posterior plot settings (require results_show=1)
plot_post_extra = 0; % =1: report posterior FEVD, long-run IRs, and autocorrelations (plot_prior_extra must be set to 1 if plots should include prior autocorrelations)
plot_post_inv = 0; % =1: report posterior probability of invertibility, histogram of smallest MA root, R-square values, and closest invertible IRFs (plot_prior_inv must be set to 1 if plots should include prior summaries of these measures)
plot_post_pred = 0; % =1: report posterior predictive checks
plot_post_shocks = 0; % =1: posterior of standardized structural shocks (means, as well as percentiles of absolute values) should be plotted against time
plot_post_sens = 0; % =1: report M�ller (2012) measure of posterior sensitivity to prior

% Other settings
signif_level = 0.1; % Significance level for prior/posterior intervals
R_square_lags = 50; % Base R-square calculations on population regressions that use this many lags of the data
check_fcts = @(x) [skewness(x); kurtosis(x)-3; hac_vec(x, @(z) 1-abs(z), 21)./var(x,1); autocorr_var_res_sq(x,8)]'; % Predictive checking functions: Takes as argument a (T x n) dataset and returns an (n x m) matrix
check_fct_titles = {'Skewness', 'Excess kurtosis', 'Long-run corr.', 'Autocorr. sq. VAR res.'}; % Label for each of the m checking functions
ic_max_q = 25; % Maximum q to compute information criteria for

% Random number settings
rng(115091752); % Seed RNG
%rng('shuffle');

% *** END SETTINGS



% *** INITIAL MANIPULATIONS ***

addpath(fullfile('.', 'data_sim'), fullfile('.', 'densities'), fullfile('.', 'identif_set'), fullfile('.', 'nuts'), fullfile('.', 'reporting')); % Add paths for auxiliary files
current_rng = rng; % Store RNG settings


% *** LOAD AND PLOT PRIOR

if plot_prior == 1 || load_data == 1 || run_nuts == 1;

    run(prior_filename);
    n = length(prior.norm_var); % Number of variables

    inds = sub2ind([n n], prior.norm_var, 1:n); % Linear indices of normalized IR coef's
    prior.tau(inds) = 0; % Set prior standard deviation to zero for normalized IR coef's

end;

if plot_prior == 1;
    
    [~, ~, ~, prior_Theta_draws, prior_log_sigma_draws] = prior_svma(prior, [], [], plot_prior_draws); % Draw from prior
    
    plot_tile( @(i,j) plot_irf(i, j, prior.mu, prior.mu-norminv(1-signif_level/2)*prior.tau, prior.mu+norminv(1-signif_level/2)*prior.tau, [], [], [], prior_Theta_draws, plot_prior_colors, []), ...
               'Prior: IRFs', prior); % Plot prior mean IRFs with 90% bands
    
    if plot_prior_mean == 1;
        
        plot_tile( @(i,j) plot_irf(i, j, prior.mu, [], [], [], [], [], [], [], []), ...
               'Prior mean: IRFs', prior); % Plot only prior mean IRFs
        
    end;
    
    if plot_prior_extra == 1 || plot_prior_inv == 1 || plot_prior_pred == 1;
        
        [~, ~, ~, prior_Theta_comp_draws, prior_log_sigma_comp_draws] = prior_svma(prior, [], [], plot_prior_comp_draws); % Draw more samples from prior
        
    end;
    
    if plot_prior_extra == 1;
        
        plot_tile(@(i,j) plot_longrun_hist(i, j, [], prior), 'Prior: long-run IRs', prior); % Plot histogram of long-run IRs
        plot_FEVD(prior_Theta_comp_draws, prior_log_sigma_comp_draws, signif_level, 'Prior: FEVD', prior); % Plot FEVD
        autocorr_draws_prior = plot_autocorr(prior_Theta_comp_draws, prior_log_sigma_comp_draws, signif_level, 'Prior: Autocorr.', prior); % Plot autocorrelations
        
    end;
    
    if plot_prior_inv == 1; % If prior probability of invertibility should be reported...
        
        smallest_root_draws_prior = plot_smallest_root(prior_Theta_comp_draws, [], 'Prior: smallest MA root', []); % Plot histogram of smallest MA root
        R_square_draws_prior = plot_R_square(prior_Theta_comp_draws, prior_log_sigma_comp_draws, R_square_lags, 'Prior: R-square', prior, []); % Plot histogram of R-squares from regressions of shocks on past data
        
    end;
    
end;


% *** LOAD AND PLOT DATA

if load_data == 1;
    
    run(data_filename);
    [T,n] = size(Y); % Sample size
    Y_tilde = fft(Y)/sqrt(T); % Normalized Discrete Fourier Transform of data (note: I don't divide by 2*pi here, unlike in paper)
    
    if ~exist('time', 'var');
        time = [];
    end;
    
    if plot_data == 1; % If data and autocorrelations should be plotted...
        
        if exist('Y_raw', 'var') && exist('Y_trend', 'var');
            plot_series(Y_raw, Y_trend, time, 'Data: raw and trend', prior); % Plot original data and trend
        end;
        
        plot_series(Y, [], time, 'Data: detrended', prior); % Plot final data
        
        % Compute autocorrelations
        autocorrs = zeros(1+plot_data_autocorr_lag,n);
        for i=1:n;
            autocorrs(:,i) = autocorr(Y(:,i), plot_data_autocorr_lag);
        end;
        
        plot_series(autocorrs, [], 0:plot_data_autocorr_lag, 'Data: detrended autocorr.', prior); % Plot autocorrelations of final data
        
    end;
    
    if plot_ic == 1; % If AIC criterion should be plotted...
        
        [aic, bic] = plot_ic_svma(Y, Y_tilde, ic_max_q); % Plot AIC values
        
    end;
    
    if plot_truth == 1 && exist('Theta_true', 'var'); % If true value should be plotted...
        
        plot_tile( @(i,j) plot_irf(i, j, Theta_true, prior.mu-norminv(1-signif_level/2)*prior.tau, prior.mu+norminv(1-signif_level/2)*prior.tau, [], [], [], [], [], []), ...
               'True value: IRFs', prior); % Plot true IRFs
        
    end;
    
    if plot_prior_pred == 1; % If prior predictive checks should be reported...
        
        plot_pred_check(Y, prior_Theta_comp_draws, prior_log_sigma_comp_draws, check_fcts, check_fct_titles, 'Prior: Predictive checks', prior); % Plot prior predictive checks
        
    end;

end;


% *** NUTS ALGORITHM

if run_nuts == 1;
    
    run(settings_filename);
    
    % Default settings
    
    if ~isfield(nuts, 'store_every');
        nuts.store_every = 1; % Default: Store every MCMC step
    end;
    
    if ~isfield(nuts, 'target_rate');
        nuts.target_rate = 0.6; % Default NUTS target rate
    end;
    
    if ~isfield(nuts, 'mass_adapt');
        nuts.mass_adapt = 0; % Default: do not adapt mass matrix
    end;
    
    if ~isfield(nuts, 'mass_adapt_times');
        nuts.mass_adapt_times = []; % Default: do not adapt mass matrix
    end;
    
    if ~isfield(nuts, 'mass_adapt_shrinkage');
        nuts.mass_adapt_shrinkage = 1e-4; % Default mass matrix shrinkage factor
    end;
    
    if ~isfield(nuts, 'min_epsilon');
        nuts.min_epsilon = 0; % Default: no minimum step size
    end;
    
    if ~isfield(nuts, 'jitter');
        nuts.jitter = 0; % Default: no jitter
    end;
    
    if ~isfield(nuts, 'max_depth');
        nuts.max_depth = 20; % Default max tree depth
    end
    
    if ~isfield(nuts, 'print_epsilon');
        nuts.print_epsilon = 0; % Default: do not display step size at each iteration
    end
    
    assert(mod(nuts.num,nuts.store_every) + mod(nuts.burnin,nuts.store_every) == 0); % Check that number of draws and burn-in are multiples of "store_every"
    
    
    % Initialization
    
    disp('Computing approximate posterior mode...');
    nuts_init_draw = init_guess_svma(Y, Y_tilde, prior); % Initial value (hopefully close to mode)
    [~, nuts_init_Theta_draw] = reparam_vec(prior, nuts_init_draw);
    
    if plot_init_draw == 1;
        plot_tile( @(i,j) plot_irf(i, j, prior.mu, [], [], [], [], [], nuts_init_Theta_draw, [], []), 'Initial IRF', prior); % Plot initial IRF value
        return;
    end;
    disp(' ');
    
    
    % Run NUTS
    
    nuts_timer = tic; % Start timer
    
    p = @(param_vec) logpost_vec(Y_tilde, prior, param_vec); % Log posterior for vectorized parameter (can also return gradient)
    
    disp('Running NUTS...');
    [nuts_draws, nuts_adapt_epsilon, nuts_avg_acceptprob, nuts_adapt_mass] = nuts_da_svma(p, nuts, nuts_init_draw(:)'); % Run NUTS
    disp(' ');
    nuts_num_stored = nuts.num/nuts.store_every; % Number of stored draws
    
    % Compute weights
    
    nuts_ll_whittle = zeros(1,nuts_num_stored);
    nuts_ll_kf = zeros(1,nuts_num_stored);
    
    disp('Computing weights...');
    for k=1:nuts_num_stored; % For each stored draw...
        
        the_Psi = reparam_vec(prior, nuts_draws(k,:)); % Phi parameter corresponding to this draw
        nuts_ll_whittle(k) = whittle_svma(Y_tilde, the_Psi); % Whittle log likelihood
        nuts_ll_kf(k) = kf_svma(Y, the_Psi); % Exact log likelihood
        
        if mod(k, floor(nuts_num_stored/25)) == 0;
            fprintf('%1s', '.'); % Print progress
        end;
        
    end;
    disp(' ');
    
    nuts_ll_diff = nuts_ll_kf - nuts_ll_whittle; % Log likelihood difference
    nuts_weights = exp(nuts_ll_diff - max(nuts_ll_diff)); % Compute weights (to avoid numerical error, only exponentiate negative numbers)
    nuts_weights = nuts_weights/sum(nuts_weights); % Normalize
    
    % Store results
    
    nuts_log_sigma_draws = nuts_draws(:,inds); % Store draws of log(sigma)
    nuts_draws(:,inds) = repmat(prior.mu(inds), nuts_num_stored, 1); % Insert normalized IR coef's in chain
    
    nuts_Theta_draws = reshape(nuts_draws', [size(prior.mu) nuts_num_stored]); % Reshape draws
    clearvars nuts_draws; % Free up disk space
    
    nuts_elapsed_time = toc(nuts_timer); % Stop timer
    
    if results_store == 1;
        save(results_filename); % Save results if desired
    end;
    
end;


% *** SHOW RESULTS

if results_show == 1;
    
    if run_nuts == 0; % If algorithm hasn't been run above, load stored results
        load(results_filename, 'nuts*', 'prior', '*_true', 'Y', 'Y_tilde', 'time', 'T', 'n', 'current_rng');
    end;
    
    % If values haven't been set above, set them equal to null
    if ~exist('Theta_true', 'var');
        Theta_true = [];
    end;
    if ~exist('sigma_true', 'var');
        sigma_true = [];
    end;
    if ~exist('autocorr_draws_prior', 'var');
        autocorr_draws_prior = [];
    end;
    if ~exist('smallest_root_draws_prior', 'var');
        smallest_root_draws_prior = [];
    end;
    if ~exist('R_square_draws_prior', 'var');
        R_square_draws_prior = [];
    end;
    
    results_svma(nuts_Theta_draws, nuts_log_sigma_draws, nuts_avg_acceptprob, nuts_elapsed_time, Theta_true, sigma_true, Y, time, plot_post_extra, plot_post_inv, plot_post_pred, plot_post_shocks, plot_post_sens, signif_level, R_square_lags, autocorr_draws_prior, smallest_root_draws_prior, R_square_draws_prior, check_fcts, check_fct_titles, prior, nuts); % Report results
    
end;


