% Prior for news shock application

prior = struct;

q = 16; % Max IRF horizon

load('../dynare_news/news_irf_grid_horiz3', 'irf_grid');

prior.var_names = {'TFP growth', 'GDP growth', 'Real IR'}; % Variable names
prior.shock_names = {'Prod. shock', 'News shock', 'MP shock'}; % Shock names

% IRF means
prior.mu = irf_grid(:,:,1:q+1); % Default prior means from Dynare
irf_prod_news = prior.mu(1,2,:); % Dynare IRF for TFP growth to news shock
antic_lag = find(irf_prod_news > 1e-10) - 1; % Anticipation lag in the DSGE calibration
irf_prod_news_smoothed = (0:q).*max(2*antic_lag - (0:q),0)/antic_lag^2*irf_prod_news(antic_lag+1)/2; % Smooth out the IRF
prior.mu(1,2,:) = irf_prod_news_smoothed; % New smoothed prior mean


prior.tau = zeros(3,3,q+1); % IRF standard deviations
decreasing_trend = linspace(1, 0.4, q+1); % Decreasing linear function
path_hump = @(top) betapdf(linspace(0, 1, q+1), 2, q/top)/betapdf(top/q, 2, q/top); % Hump-shaped function
prior.tau(1,1,:) = 0.2*decreasing_trend;
prior.tau(1,2,:) = 0.6*prior.mu(1,2,:) + 0.2;
prior.tau(1,3,:) = 0.05;
prior.tau(2,1,:) = 0.2*decreasing_trend;
prior.tau(2,2,:) = 0.5*path_hump(4) + 0.2;
prior.tau(2,3,:) = 0.3*decreasing_trend;
prior.tau(3,1,:) = 0.07*decreasing_trend;
prior.tau(3,2,:) = decreasing_trend;
prior.tau(3,3,:) = 0.15*decreasing_trend;

prior.rho = [0.5 0.5 0.5;
             0.9 0.9 0.9;
             0.9 0.9 0.9]; % IRF smoothness

prior.norm_var = [1 2 3]; % Which response to normalize (i.e., fix) for each shock
prior.tau_sigma = 2*ones(1,3); % Std. dev's of log(sigma)
prior.mu_sigma = log(0.5)*ones(1,3); % Means of log(sigma)

