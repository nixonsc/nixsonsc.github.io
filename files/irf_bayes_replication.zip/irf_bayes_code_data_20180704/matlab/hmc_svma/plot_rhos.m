clear;

% *******************************************
% *** Plot prior draws for different rhos ***
% *** Bivariate model                     ***
% *** MPM, 2017-07-07                     ***
% *******************************************


% *** SETTINGS

rho_vals = [0.3 0.9 0.99]; % Values of rho to plot
plot_i = 1; % Plot IRF for this observed variables
plot_j = 2; % Plot IRF for this shock

signif_level = 0.1; % Significance level
plot_prior_draws = 4; % Number of prior draws to plot
the_ylim = [-0.5 1.5]; % Limits of vertical axis
plot_prior_colors = {[1 0 0], [0.2 0.7 0], [0.9 0.5 0], [0 0 1]}; % Colors for draws

rng(201706074); % Set RNG

% *** END SETTINGS

addpath(fullfile('.', 'data_sim'), fullfile('.', 'densities'), fullfile('.', 'reporting')); % Add paths for auxiliary files

prior_bivariate; % Load bivariate model prior

figure('Units', 'normalize', 'Position', [0.1 0.3 0.8 0.4]);
for j=1:length(rho_vals); % For each value of rho...
    
    the_prior = prior;
    the_prior.rho = rho_vals(j)*ones(2); % Only change rho in the prior specification
    [~, ~, ~, the_prior_Theta_draws] = prior_svma(the_prior, [], [], plot_prior_draws); % Prior draws
    
    % Plot draws
    subtightplot(1, length(rho_vals), j, [0 0.05], 0.1, [0.04 0.01]);
    plot_irf(plot_i, plot_j, the_prior.mu, the_prior.mu-norminv(1-signif_level/2)*the_prior.tau, the_prior.mu+norminv(1-signif_level/2)*the_prior.tau, [], [], [], the_prior_Theta_draws, plot_prior_colors, []);
    ylim(the_ylim);
    set(gca,'FontSize', 12); % Adjust plot font size
    title(sprintf('%s%4.2f%s', '$\rho=', rho_vals(j), '$'), 'FontSize', 16, 'Interpreter', 'LaTex');

end;