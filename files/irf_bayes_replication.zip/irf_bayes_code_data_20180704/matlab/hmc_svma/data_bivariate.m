% Simulated data for bivariate simulation example

Theta_true = prior.mu; % True IRFs
sigma_true = exp(prior.mu_sigma); % True shock standard deviations

[Y, SVMA_model] = sim_svma(Theta_true, sigma_true, 200, prior); % Simulate data with T=200
disp(SVMA_model); % Display model specification
