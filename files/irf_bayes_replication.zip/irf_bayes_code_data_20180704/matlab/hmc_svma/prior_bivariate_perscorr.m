% Prior for bivariate simulation example, misspecified persistence and correlation

prior_bivariate; % Same as baseline prior...
prior.tau = 1.5*prior.tau; % ... except larger IRF standard deviations
