% Simulated data for bivariate simulation example, misspecified prior: cross-correlation

Theta_true = prior.mu; % True IRFs
Theta_true(2,1,:) = 0; % Set (2,1) IRF equal to zero
sigma_true = exp(prior.mu_sigma); % True shock standard deviations

[Y, SVMA_model] = sim_svma(Theta_true, sigma_true, 200, prior); % Simulate data with T=200
disp(SVMA_model); % Display model specification
