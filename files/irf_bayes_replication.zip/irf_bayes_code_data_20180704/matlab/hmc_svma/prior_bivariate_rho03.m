% Prior for bivariate simulation example, rho=0.3

prior_bivariate;
prior.rho = 0.3*ones(2); % IRF smoothness
