% Simulated data for bivariate simulation example, misspecified prior: persistence and cross-correlation

data_bivariate_pers; % Same prior as for the misspecified persistence experiment...
Theta_true(2,1,:) = 0; % ... except set (2,1) IRF equal to zero

[Y, SVMA_model] = sim_svma(Theta_true, sigma_true, 200, prior); % Simulate data with T=200
disp(SVMA_model); % Display model specification
