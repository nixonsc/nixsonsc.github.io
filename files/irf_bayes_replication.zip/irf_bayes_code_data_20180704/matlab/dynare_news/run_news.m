clear all;

% *************************************************
% *** Run Dynare code to obtain news shock IRFs ***
% *** Based on model and code by Eric Sims      ***
% *** MPM, 2015-11-18                           ***
% *************************************************


% *** Settings

% Exogenously chosen parameters (quarterly frequency)
beta = 0.99; % Discount factor
delta = 0.02; % Depreciation rate
g_a = 0.0025; % Average growth rate of TFP
pi_star = 0.005; % Inflation rate target
alpha = 1/3; % Steady-state labor share
xi = 1; % Inverse Frisch elasticity
gamma = 0.7; % Habit formation parameter
tau = 2.5; % Investment adjustment cost parameter
phi = 0.7; % Calvo parameter (probability of price being stuck in a given period)
omega = 0; % Fraction of rule-of-thumb price-setters (Gali & Gertler, 1999) - ONLY DIFFERENCE FROM ERIC SIMS PAPER (SET TO ZERO TO REVERT TO SIMS MODEL)
epsilon = 11; % Demand elasticity of substitution
rho = 0.8; % Interest rate rule smoothing parameter
psi_pi = 1.5; % Interest rate rule inflation parameter
psi_y = 0.5; % Interest rate rule output growth parameter
n_ss = log(1/3); % Steady state for log hours

% Plot settings
shocks = {'a_shock', 'news_shock', 'i_shock'}; % Shocks to plot
vars =   {'lambda', 'mu', 'y', 'c', 'I', 'k', 'w', 'n', 'R', 'mc', 'p_rel', 'pi', 'i', 'i_minus_pi', 'i_real'}; % Variables to plot (names without "_hat" suffix) - without "a"
norm_a = [-1,       -1,   1,   1,   1,   1,   1,   0,   0,   0,    0,       0,    0,   0,            0]; % =1 if variable has been divided by a^(1/(1-alpha)), =-1 if variable has been multiplied by a^(1/(1-alpha)), =0 if variable is un-normalized

grid_vars =         {'a', 'y', 'i_minus_pi'}; % Variables to show in grid plot
grid_vars_diff =    [1,   1,   0]; % =1 if variable should be plotted in first differences
grid_vars_label =   {'\Delta a_t', '\Delta y_t', 'i_t - \pi_t'}; % Labels for variables in the grid plot
grid_shocks_norm = [1, 2, 3]; % Which grid variable to normalize to 1 on impact, for each shock

% Save settings
save_file = 1; % Save grid of IRFs in .mat file
save_name = 'news_irf_grid_horiz3'; % Name of file for storing the grid of IRFs

% *** End settings


% *** Steady state calculations

Delta = exp(g_a/(1-alpha)); % Steady-state gross growth rate for y_hat
R_ss = log(Delta/beta - (1-delta));
i_ss = log(Delta/beta) + pi_star;

p_rel_ss = log((1 - omega*(1-phi) - phi*exp((epsilon-1)*pi_star))/((1-phi)*(1-omega)))/(1-epsilon);
mc_ss = log((epsilon-1)/epsilon) + p_rel_ss + log(1 - phi*beta*exp(epsilon*pi_star)) - log(1 - phi*beta*exp((epsilon-1)*pi_star));
v_ss = log((1-phi)*((1-omega)*exp(-epsilon*p_rel_ss) + omega)/(1-phi*exp(epsilon*pi_star)));

k_hat_ss = n_ss + 1/(1-alpha)*(g_a + mc_ss + log(alpha) - R_ss);
y_hat_ss = log(Delta^alpha) + alpha*k_hat_ss + (1-alpha)*n_ss - v_ss;
I_hat_ss = log((1 - (1-delta)/Delta)) + k_hat_ss;
c_hat_ss = log(exp(y_hat_ss) - exp(I_hat_ss));
w_hat_ss = log((1-alpha)/alpha) + k_hat_ss - n_ss + R_ss - log(Delta);
lambda_hat_ss = log((Delta - beta*gamma)/(Delta - gamma)) - c_hat_ss;

theta = exp(lambda_hat_ss + w_hat_ss - xi*n_ss); % Value of theta consistent with chosen steady-state value for hours

B_ss = lambda_hat_ss + y_hat_ss - log(1 - phi*beta*exp((epsilon-1)*pi_star));
A_ss = B_ss + p_rel_ss;

dynare news noclearall nograph; % Run Dynare


% *** Compute un-normalized IRFs

vars = [vars, {'a'}]; % Add productivity variable
nv = length(vars); % Number of variables
ns = length(shocks); % Number of shocks
irfs = cell(nv,ns); % Will contains un-normalized IRFs

for j=1:ns; % For each shock...
    
    irfs{end,j} = cumsum(oo_.irfs.(['a_hat_' shocks{j}])); % Cumulative TFP growth
    for i=1:nv-1; % For each variable...
        
        if norm_a(i) == 0; % If un-normalized IRF already exists...
            
            irfs{i,j} = oo_.irfs.([vars{i} '_' shocks{j}]); % Store IRF
            
        else % If only normalized IRF exists...
            
            irfs{i,j} = oo_.irfs.([vars{i} '_hat_' shocks{j}]) + norm_a(i)/(1-alpha)*irfs{end,j}; % Un-normalize the IRF and store it
            
        end;
        
    end;
    
end;


% *** Compute IRF for first differences

irfs_diff = cell(nv,ns); % Will contain IRFs for first differences
for j=1:ns;
    for i=1:nv;
        irfs_diff{i,j} = diff([0 irfs{i,j}]); % First difference
    end;
end;


% *** Make plots of separate IRFs

nc = ceil(sqrt(nv)); % Number of columns in plot
max_horizon = length(irfs{i,j})-1; % Max impulse response horizon
plot_type = {'deviations from s.s.', 'first differences'}; % Titles of two plot types

for j=1:ns; % For each shock...
    
    shock_impact = find(abs(irfs{end,j}) > eps,1)-1; % Horizon when shock hits productivity
    
    for l=1:2; % For each type of plot (levels and growth)...
    
        figure('Name', [shocks{j} ' ' plot_type{l}], 'Units', 'normalized', 'Position', [0.05 0.1 0.9 0.8]); % Open figure

        for i=1:nv; % For each variable...

            subtightplot(nc, ceil(nv/nc), i, [0.1 0.05], 0.05, 0.05); % Tight subplot

            if l==1; % If levels...
                the_irf = irfs{i,j};
            else % If changes...
                the_irf = irfs_diff{i,j};
            end;
            the_irf = round(the_irf, 10); % Round off to the nearest 10^(-10) to remove tiny numerical errors
            
            plot(0:max_horizon, the_irf, '-k', 'LineWidth', 2); % Plot IRF
            the_ylim = ylim; % Record vertical axis limits
            hold on;
            line([0 max_horizon], [0 0], 'Color', 'k'); % Add horizontal axis
            if shock_impact > 0; % If shock hits at horizon greater than zero...
                line([shock_impact shock_impact], the_ylim, 'Color', 'k', 'LineStyle', '--'); % Mark horizon that shock hits with dashed vertical line
            end;
            hold off;
            ylim(the_ylim); % Ensure vertical axis limits remain the same
            title(vars{i}, 'FontSize', 12, 'FontName', 'FixedWidth', 'Interpreter', 'none'); % Add title to subplot

        end;
    
    end;
    
end;


% *** Make grid plot

ng = length(grid_vars); % Number of variables in grid
irf_grid = zeros(ng, ns, max_horizon+1); % Will contain IRF for each grid variable to each shock

for j=1:ns; % For each shock...
    
    for i=1:ng; % For each grid variable...
        
        var_index = find(strcmp(vars, grid_vars{i})); % Find index of current grid variable
        
        if grid_vars_diff(i)==1; % If changes...
            irf_grid(i,j,:) = irfs_diff{var_index,j};
        else % If levels...
            irf_grid(i,j,:) = irfs{var_index,j};
        end;
        irf_grid(i,j,:) = round(irf_grid(i,j,:), 10); % Round off to the nearest 10^(-10) to remove tiny numerical errors
        
    end;
    
    norm_const = irf_grid(grid_shocks_norm(j), j, 1); % Normalize shock magnitude by this number
    irf_grid(:,j,:) = irf_grid(:,j,:)/norm_const; % Normalize IRFs
    
end;

if save_file == 1;
    save(save_name, 'irf_grid', 'shocks', 'grid_vars');
end;

figure('Name', 'Grid plot', 'Units', 'normalized', 'Position', [0.1 0.1 0.8 0.8]); % Open figure (variables along rows, shocks along columns)

for i=1:ng; % For each grid variable...
    
    for j=1:ns; % For each shock...
        
        subtightplot(ng, ns, j+(i-1)*ng, [0.07 0.07], 0.07, 0.07); % Tight subplot
        
        plot(0:max_horizon, squeeze(irf_grid(i,j,:)), '-k', 'LineWidth', 2); % Plot IRF
        the_ylim = ylim; % Record vertical axis limits
        hold on;
        line([0 max_horizon], [0 0], 'Color', 'k'); % Add horizontal axis
        hold off;
        ylim(the_ylim); % Ensure vertical axis limits remain the same
        
        if i==1; % If first row...
            title(shocks{j}, 'FontSize', 12, 'FontName', 'FixedWidth', 'Interpreter', 'none'); % Add shock name as title
        end;
        if j==1; % If first column...
            ylabel(['$' grid_vars_label{i} '$'], 'FontSize', 12, 'Interpreter', 'latex'); % Add variable name as vertical label
        end;
        
    end;
    
end;


