Data List: news shocks
Data Updated: 2015-08-11

FRED (Federal Reserve Economic Data)
Link: https://research.stlouisfed.org/fred2
Help: https://research.stlouisfed.org/fred2/help-faq
Economic Research Division
Federal Reserve Bank of St. Louis

Series ID                                                             
----------------------------------------------------------------------
A939RX0Q048SBEA                                                       

Title
----------------------------------------------------------------------
Real gross domestic product per capita                                

Source
----------------------------------------------------------------------
US. Bureau of Economic Analysis                                       

Release
----------------------------------------------------------------------
Gross Domestic Product                                                

Units
----------------------------------------------------------------------
Chained 2009 Dollars                                                  

Frequency
----------------------------------------------------------------------
Quarterly                                                             

Seasonal Adjustment
----------------------------------------------------------------------
Seasonally Adjusted Annual Rate                                       

Notes
----------------------------------------------------------------------
BEA Account Code: A939RX0                                             
                                                                      
For more information about this series, please see                    
http://www.bea.gov/national/.                                         



Series ID                                                             
----------------------------------------------------------------------
B230RC0Q173SBEA                                                       

Title
----------------------------------------------------------------------
Population (midperiod)                                                

Source
----------------------------------------------------------------------
US. Bureau of Economic Analysis                                       

Release
----------------------------------------------------------------------
Gross Domestic Product                                                

Units
----------------------------------------------------------------------
Thousands                                                             

Frequency
----------------------------------------------------------------------
Quarterly                                                             

Seasonal Adjustment
----------------------------------------------------------------------
Seasonally Adjusted Annual Rate                                       

Notes
----------------------------------------------------------------------
BEA Account Code: B230RC0                                             
                                                                      
For more information about this series, please see                    
http://www.bea.gov/national/.                                         



Series ID                                                             
----------------------------------------------------------------------
FEDFUNDS                                                              

Title
----------------------------------------------------------------------
Effective Federal Funds Rate                                          

Source
----------------------------------------------------------------------
Board of Governors of the Federal Reserve System (US)                 

Release
----------------------------------------------------------------------
H.15 Selected Interest Rates                                          

Units
----------------------------------------------------------------------
Percent                                                               

Frequency
----------------------------------------------------------------------
Monthly                                                               

Seasonal Adjustment
----------------------------------------------------------------------
Not Seasonally Adjusted                                               

Notes
----------------------------------------------------------------------
Averages of daily figures.                                            
                                                                      
The federal funds rate is the interest rate at which depository       
institutions trade federal funds (balances held at Federal Reserve    
Banks) with each other overnight. When a depository institution has   
surplus balances in its reserve account, it lends to other banks in   
need of larger balances. In simpler terms, a bank with excess cash,   
which is often referred to as liquidity, will lend to another bank    
that needs to quickly raise liquidity. (1) The rate that the borrowing
institution pays to the lending institution is determined between the 
two banks; the weighted average rate for all of these types of        
negotiations is called the effective federal funds rate.(2) The       
effective federal funds rate is essentially determined by the market  
but is influenced by the Federal Reserve through open market          
operations to reach the federal funds rate target.(2)                 
The Federal Open Market Committee (FOMC) meets eight times a year to  
determine the federal funds target rate. As previously stated, this   
rate influences the effective federal funds rate through open market  
operations or by buying and selling of government bonds (government   
debt).(2) More specifically, the Federal Reserve decreases liquidity  
by selling government bonds, thereby raising the federal funds rate   
because banks have less liquidity to trade with other banks.          
Similarly, the Federal Reserve can increase liquidity by buying       
government bonds, decreasing the federal funds rate because banks have
excess liquidity for trade. Whether the Federal Reserve wants to buy  
or sell bonds depends on the state of the economy. If the FOMC        
believes the economy is growing too fast and inflation pressures are  
inconsistent with the dual mandate of the Federal Reserve, the        
Committee may set a higher federal funds rate target to temper        
economic activity. In the opposing scenario, the FOMC may set a lower 
federal funds rate target to spur greater economic activity.          
Therefore, the FOMC must observe the current state of the economy to  
determine the best course of monetary policy that will maximize       
economic growth while adhering to the dual mandate set forth by       
Congress. In making its monetary policy decisions, the FOMC considers 
a wealth of economic data, such as: trends in prices and wages,       
employment, consumer spending and income, business investments, and   
foreign exchange markets.                                             
The federal funds rate is the central interest rate in the U.S.       
financial market. It influences other interest rates such as the prime
rate, which is the rate banks charge their customers with higher      
credit ratings. Additionally, the federal funds rate indirectly       
influences longer- term interest rates such as mortgages, loans, and  
savings, all of which are very important to consumer wealth and       
confidence.(2)                                                        
References                                                            
(1) Federal Reserve Bank of New York. “Federal funds.” Fedpoints, 
August 2007.                                                          
(2) Board of Governors of the Federal Reserve System. “Monetary     
Policy”. http://www.federalreserve.gov/monetarypolicy/default.htm.  



Series ID                                                             
----------------------------------------------------------------------
GDP                                                                   

Title
----------------------------------------------------------------------
Gross Domestic Product                                                

Source
----------------------------------------------------------------------
US. Bureau of Economic Analysis                                       

Release
----------------------------------------------------------------------
Gross Domestic Product                                                

Units
----------------------------------------------------------------------
Billions of Dollars                                                   

Frequency
----------------------------------------------------------------------
Quarterly                                                             

Seasonal Adjustment
----------------------------------------------------------------------
Seasonally Adjusted Annual Rate                                       

Notes
----------------------------------------------------------------------
BEA Account Code: A191RC1                                             
                                                                      
Gross domestic product (GDP), the featured measure of U.S. output, is 
the market value of the goods and services produced by labor and      
property located in the United States.                                
                                                                      
For more information, see the Guide to the National Income and Product
Accounts of the United States (NIPA) -                                
(http://www.bea.gov/national/pdf/nipaguid.pdf)                        



Series ID                                                             
----------------------------------------------------------------------
GDPC1                                                                 

Title
----------------------------------------------------------------------
Real Gross Domestic Product                                           

Source
----------------------------------------------------------------------
US. Bureau of Economic Analysis                                       

Release
----------------------------------------------------------------------
Gross Domestic Product                                                

Units
----------------------------------------------------------------------
Billions of Chained 2009 Dollars                                      

Frequency
----------------------------------------------------------------------
Quarterly                                                             

Seasonal Adjustment
----------------------------------------------------------------------
Seasonally Adjusted Annual Rate                                       

Notes
----------------------------------------------------------------------
BEA Account Code: A191RX1                                             
                                                                      
Real gross domestic product is the inflation adjusted value of the    
goods and services produced by labor and property located in the      
United States.                                                        
                                                                      
For more information see the Guide to the National Income and Product 
Accounts of the United States (NIPA) -                                
(http://www.bea.gov/national/pdf/nipaguid.pdf)                        



Series ID                                                             
----------------------------------------------------------------------
IPDNBS                                                                

Title
----------------------------------------------------------------------
Nonfarm Business Sector: Implicit Price Deflator                      

Source
----------------------------------------------------------------------
US. Bureau of Labor Statistics                                        

Release
----------------------------------------------------------------------
Productivity and Costs                                                

Units
----------------------------------------------------------------------
Index 2009=100                                                        

Frequency
----------------------------------------------------------------------
Quarterly                                                             

Seasonal Adjustment
----------------------------------------------------------------------
Seasonally Adjusted                                                   



