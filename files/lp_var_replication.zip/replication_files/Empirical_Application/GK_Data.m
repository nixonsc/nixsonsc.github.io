% Load Gertler-Karadi (2015) data

%% SETTINGS

% Data
data_file = 'gk2015.csv'; % Data file
sample = [datetime('1990-1-1'), datetime('2012-06-01')]; % Sample end points
endo_vars = {'gs1', 'dlogip', 'dlogcpi', 'ebp'}; % Endogenous (w) variables: 1-year bond rate, log growth rate of IP (annualized), log growth rate of CPI (annualized), EBP
iv_var = 'ff4_tc'; % External IV (z)


%% LOAD DATA

dat_table = readtable(data_file, 'Format', strcat('%s', repmat('%f', 1, 20))); % Read from file
sample_bool = datetime(dat_table.date) >= sample(1) & datetime(dat_table.date) <= sample(2); % Sample marker

time = dat_table.date(sample_bool); % Timestamps
Y = dat_table{sample_bool, endo_vars}; % Endogenous variables
Z = dat_table{sample_bool, iv_var}; % External IV

data = [Y Z]; % Data matrix
