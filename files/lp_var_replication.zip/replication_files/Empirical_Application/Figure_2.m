%% GERTLER-KARADI APPLICATION
% Mikkel Plagborg-M�ller & Christian K. Wolf
% This version: 05/26/2020

%% HOUSEKEEPING

clc
clear all
close all

path = pwd;

cd(path);
addpath('../_auxiliary_functions')

%% SETTINGS

% Variable indices
iy = 4; % Response variable
ix = 1; % Normalization variable

% Horizons to plot
maxhorz = 36;

% Lag lengths to plot
ps = [12 24]; % Exogenously compute results for these lag lengths
p_max_ic = 24; % Max lag length for AIC/BIC

% Plot settings
plot_xticks = 0:6:36;
plot_ylim = [-1 2.5];

%% LOAD DATA

GK_Data;
[T,ny] = size(Y);

%% ESTIMATION

%----------------------------------------------------------------
% Information Criteria
%----------------------------------------------------------------

[BIC,AIC] = IC_VAR(data,p_max_ic);
[~,p_BIC] = min(BIC);
[~,p_AIC] = min(AIC);

%----------------------------------------------------------------
% Estimate: Recursive VAR, LP-IV, SVAR-IV
%----------------------------------------------------------------

% ps_expand = unique([ps p_BIC p_AIC]); % List of all lag lengths to consider
ps_expand = [4 6 8 10 12]; % List of all lag lengths to consider
np = length(ps_expand);

irfs_var = zeros(np,maxhorz+1);
irfs_lpiv = zeros(np,maxhorz+1);
irfs_svariv = zeros(np,maxhorz+1);

for i_p=1:np % For each lag length...
    
    % Lag length
    the_p = ps_expand(i_p);
    
    % VAR with IV ordered first
    [~,the_By_full,the_Sigma_full,~,the_res_full] = VAR_mod([Z Y],the_p); % VAR w. IV
    the_chol = chol(the_Sigma_full)'; % Impact impulse responses
    the_irf_var = IRF_SVAR(the_By_full,the_chol(:,1),maxhorz);
    irfs_var(i_p,:) = the_irf_var(1+iy,:)/the_irf_var(1+ix,1);
    
    % LP-IV
    irfs_lpiv(i_p,:) = IRF_LP_IV([Z Y(:,ix) Y(:,iy) Y(:,setdiff(1:ny,[ix iy]))],2,1,the_p,maxhorz);
    
    % SVAR-IV
    Ztilde = the_res_full(:,1); % Residualized IV
    [~,the_By,~,~,the_res] = VAR_mod(Y,the_p); % VAR w/o IV
    the_irf_svariv = IRF_SVAR(the_By,the_res'*Ztilde/(T-the_p),maxhorz); % SVAR-IV IRFs
    irfs_svariv(i_p,:) = the_irf_svariv(iy,:)/the_irf_svariv(ix,1);
    
end

%% PLOT

%----------------------------------------------------------------
% Preparations
%----------------------------------------------------------------

settings.colors.black  = [0 0 0];
settings.colors.grey   = [205/255 205/255 205/255];
settings.colors.orange = [204/255 102/255 0/255];
settings.colors.green  = [37/255 152/255 14/255];
settings.colors.blue   = [51/255 51/255 255/255];
settings.colors.red    = [255/255 0/255 0/255];

settings.colors.list = [settings.colors.black;settings.colors.grey;settings.colors.orange];

maxhorz = 24;

indx_p_1 = 1;
indx_p_2 = 5;

plotwidth = 0.4;
gapsize = 0.1;
gapsize_edges = (1-2*plotwidth-1*gapsize)/2;
left_pos = [gapsize_edges, gapsize_edges + gapsize + plotwidth];

%----------------------------------------------------------------
% Plot
%----------------------------------------------------------------

figure(1)
subplot(1,2,1)
pos = get(gca, 'Position');
pos(1) = left_pos(1);
pos(3) = plotwidth;
set(gca,'Position', pos)
hold on
plot(0:1:maxhorz,irfs_var(indx_p_1,1:maxhorz+1),'Color',settings.colors.blue,'LineWidth',3,'LineStyle',':')
hold on
plot(0:1:maxhorz,irfs_lpiv(indx_p_1,1:maxhorz+1),'Color',settings.colors.red,'LineWidth',3,'LineStyle','--')
hold on
plot([ps_expand(indx_p_1) ps_expand(indx_p_1)],plot_ylim,'Color',settings.colors.black,'LineStyle','-','LineWidth',2)
hold on
set(gcf,'color','w')
title('$p$ = 4','interpreter','latex','fontsize',22)
xlabel('Horizon (monthly)','interpreter','latex','FontSize',20)
ylabel('\% deviation','interpreter','latex','FontSize',20)
xlim([0 maxhorz])
ylim(plot_ylim)
grid on
hold off

subplot(1,2,2)
pos = get(gca, 'Position');
pos(1) = left_pos(2);
pos(3) = plotwidth;
set(gca,'Position', pos)
hold on
plot(0:1:maxhorz,irfs_var(indx_p_2,1:maxhorz+1),'Color',settings.colors.blue,'LineWidth',3,'LineStyle',':')
hold on
plot(0:1:maxhorz,irfs_lpiv(indx_p_2,1:maxhorz+1),'Color',settings.colors.red,'LineWidth',3,'LineStyle','--')
hold on
plot([ps_expand(indx_p_2) ps_expand(indx_p_2)],plot_ylim,'Color',settings.colors.black,'LineStyle','-','LineWidth',2)
hold on
set(gcf,'color','w')
title('$p$ = 12','interpreter','latex','fontsize',22)
xlabel('Horizon (monthly)','interpreter','latex','FontSize',20)
ylabel('\% deviation','interpreter','latex','FontSize',20)
legend({'SVAR','LP'},'Location','Northeast','fontsize',20,'interpreter','latex')
xlim([0 maxhorz])
ylim(plot_ylim)
grid on
hold off
pos = get(gcf, 'Position');
set(gcf, 'Position', [pos(1) pos(2) 1.75*pos(3) 1.075*pos(4)]);
set(gcf, 'PaperPositionMode', 'auto');
print('GK_Illustr','-depsc');