Replication files for:
"Local Projections and VARs Estimate the Same Impulse Responses"
by Mikkel Plagborg-Møller and Christian K. Wolf

Code tested in: (i)  Matlab R2020a with Dynare 4.6.1 on Windows 10 PC
                (ii) Matlab R2019b with Dynare 4.5.4 on macOS 10.15.6

* Requirements:
- Dynare for Matlab: https://www.dynare.org

* Replication steps in Matlab:
1. Run DSGE_Illustration/SW_FP/SW_FP_Main.m
2. Run DSGE_Illustration/SW_MP/SW_MP_Main.m
3. Run DSGE_Illustration/Figure_1.m (this produces Figure 1 in the paper)
4. Run Empirical_Application/Figure_2.m (this produces Figure 2 in the paper)

* Acknowledgements:
- The Dynare files for solution of the Smets & Wouters (2007) model are based on replication code kindly provided by Johannes Pfeifer.
- The data for the empirical application was obtained from the online replication files for Gertler & Karadi (2015): https://www.aeaweb.org/articles?id=10.1257/mac.20130329


