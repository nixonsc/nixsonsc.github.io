***********************************************************************************
Matlab files for reproducing Figures 1-7 and Tables 1-3 in
"Consistent Factor Estimation in Dynamic Factor Models with Structural Instability"
by B. J. Bates, M. Plagborg-Moller, J. H. Stock and M. W. Watson

2012-12-03
***********************************************************************************


The following is a short description of the Matlab files that produce Figures 1-7 and Tables 1-3. All files have been extensively annotated.

- The two main m-files are run_mc.m (Figures 1-6, Tables 1-3) and run_mc_raterw.m (Figure 7). Parameter values for the simulations are set at the top of these files. For run_mc.m, the default parameter values produce Figures 1-3; to produce Figures 4-6, see lines 58, 74 and 90, and adjust the arrays ds, cs and bs as described in the article.

- plot_mc.m and table_mc.m generate figures and tables after execution of run_mc.m.

- drawplot.m, genvars.m, ppc.m and summ_stats.m are auxiliary functions used by run_mc.m and run_mc_raterw.m.

NOTE: The default number of repetitions requires hours of computation time on an average computer.