# Replication files for "Robust Empirical Bayes Confidence Intervals"

The `src/` directory contains 4 `R` scripts and 5 Matlab scripts, described below. The scripts should be called from the `src` directory. All output is saved in the `output/` directory. The subdirectories `src/ebci/`, `src/ebci_general/`, and `src/sim/` contain auxiliary Matlab functions and data.

The `R` scripts require packages `ebci`, `ggthemr`, `ggplot2`, `scales`, `tikzDevice`, `ggrepel`, `metR`, `directlabels`, `knitr`, `tidyr`, and `lpSolve`. All packages except `ggthemr` are available on CRAN. `ggthemr` can be installed from github using `remotes::install_github("Mikata-Project/ggthemr")`.

The Matlab scripts require the Deep Learning, Optimization, and Parallel Computing toolboxes.

## src/empirical_application.R

This R script reproduces the empirical application.

Produces Figure 6 in tikz format:
- ch_ny_paper_0.1.tex

Also Produces Table 3 as a text file in the output file
`empirical_appplication.out`. This output file also contains the R2 statistics
cited in Section 7.2.

## src/plots_paper.R

This R script replicates Figures 1--5 in the main text.

Produces figures 1--5 in text, as tikz figures:
- cond_coverage.tex
- cva_0.05_paper.tex
- ebci_efficiency_paper.tex
- ebci_efficiency_unshrunk_paper.tex
- param_noncoverage_paper.tex

Also produces efficiency calculations comparing the robust EBCI to the
parametric EBCI in the Section 4.2 in the output file `plots_paper.out`.

## src/plots_supplement.R

This R script replicates Figure S1 in the supplemental appendix as a tikz
figure:
- power_difference.tex

## src/np_functions.R

Functions used by `empirical_application.R` for nonparametric estimation of
moments.

## src/run_softthresh.m

This Matlab script replicates Figure S2 in the supplemental appendix as EPS figures:
- softthresh_cov.eps
- softthresh_lng.eps

## src/run_poisson.m

This Matlab script replicates Figure S3 in the supplemental appendix as EPS figures:
- poisson_cov.eps
- poisson_lng.eps

## src/run_sim_panel.m

This Matlab script runs the simulation study in Section 4.4. Run the script with the setting `id = 1`, then again with the setting `id = 2`, and continue this way up to and including `id = 12`. After execution, run the script `tab_write_paper.m` with the setting `design_type = 'panel'`; first with the setting `error_type = 'normal'` and then again with the setting `error_type = 'chi2'`. This produces Tables 1 and 2 in Latex format:
- tables_paper/alpha05/avg_cov_lows_panel_normal.tex
- tables_paper/alpha05/avg_lng_avgs_panel_normal.tex
- tables_paper/alpha05/avg_cov_lows_panel_chi2.tex
- tables_paper/alpha05/avg_lng_avgs_panel_chi2.tex

## src/run_sim_ch.m

This Matlab script runs the simulation study in Supplemental Appendix E.2. After execution, run the script `tab_write_paper.m` with the setting `design_type = 'ch'` to produce Table S1 in Latex format:
- tables_paper/alpha05/avg_cov_lows_ch.tex
- tables_paper/alpha05/avg_lng_avgs_ch.tex

## src/ebci/

Auxiliary Matlab functions used by `run_sim_panel.m` and `run_sim_ch.m`.

## src/ebci_general/

Auxiliary Matlab functions used by `run_softthresh.m` and `run_poisson.m`.

## src/sim/

Auxiliary Matlab functions and data used by `run_sim_panel.m` and `run_sim_ch.m`.
