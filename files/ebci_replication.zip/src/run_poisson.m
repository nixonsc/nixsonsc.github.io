clear all;
addpath('ebci_general');

% Robust EBCI for Poisson data

% MPM 2021-01-19


%% Settings

% Sampling density and baseline prior
dens = @(y,theta) poisspdf(y,theta);                % Density for Y|theta
k = 1;                                              % Shape parameter of baseline prior
prior0 = @(theta,lambda) gampdf(theta,k,lambda);    % Baseline Gamma prior
marg0 = @(y,lambda) nbinpdf(y,k,1/(1+lambda));      % Baseline marginal distribution

% Moment constraint function
constr = @(theta,lambda) theta.^[1; 2] - [k*lambda; (k^2+k)*lambda^2]; % 1st and 2nd moment

% Significance level
alpha = 0.05;

% CI to calibrate
ci_lb = @(y,chi,lambda) gaminv(alpha/2,max(exp(-chi)*k+y,0.01),1/(1+exp(-chi)/lambda)); % Lower endpoint
ci_ub = @(y,chi,lambda) gaminv(1-alpha/2,1+exp(-chi)*(k-1)+y,1/(1+exp(-chi)/lambda)); % Upper endpoint

% Plot and numerical settings
lambdas = 0.05:0.05:4;    % lambda values to plot
numgrid_theta = 500;    % No. of grid points for theta in linear program
grid_y = 0:30;          % Support of Y


%% Compute EBCIs

nv = length(lambdas);
chis = nan(nv,2);
lngs = nan(nv,3);
covprobs = nan(nv,2);
lfds = nan(nv,numgrid_theta,2);

timer = tic;

% Compute EBCIs for each value of a and b
parfor ii=1:nv
% for ii=1:nv
    
    fprintf('%2d/%2d\n', ii, nv);
    the_lambda = lambdas(ii);
    the_marg0 = @(y) marg0(y,the_lambda);
    
    the_lfds = nan(numgrid_theta,2);
    the_lfds(:,1) = linspace(1e-6,gaminv(0.999,k,the_lambda),numgrid_theta); % theta grid
    
    the_chis = nan(1,2);
    the_lngs = nan(1,3);
    the_covprobs = nan(1,2);
    
    % Parametric and robust EBCI
    [the_chis(1), the_lngs(1), the_covprobs(1), the_chis(2), the_lngs(2), the_covprobs(2), the_lfds(:,2)] ...
        = ebci(dens, ...
               @(theta) prior0(theta,the_lambda), ...
               the_marg0, ...
               @(theta) constr(theta,the_lambda), ...
               @(y,theta,chi) min(theta-ci_lb(y,chi,the_lambda),0)+min(ci_ub(y,chi,the_lambda)-theta,0), ... % Negative when CI does not cover
               @(y,chi) ci_ub(y,chi,the_lambda)-ci_lb(y,chi,the_lambda), ... % CI length
               alpha, grid_y, the_lfds(:,1)', false);
    
    % Expected length of unshrunk CI
    the_lngs(3) = (ci_ub(grid_y,Inf,the_lambda)-ci_lb(grid_y,Inf,the_lambda)) ...
                  *the_marg0(grid_y)';
    
    chis(ii,:) = the_chis;
    covprobs(ii,:) = the_covprobs;
    lngs(ii,:) = the_lngs;
    lfds(ii,:,:) = the_lfds;
    
end

elapsed_time = toc(timer);
disp('Elapsed time (min):');
disp(elapsed_time/60);


%% Save results

mkdir('results');
save(fullfile('results', 'poisson'));


%% Figures

figure('Units', 'inches', 'Position', [0 0 4 4]);
plot(lambdas, covprobs(:,1), '--k', 'LineWidth', 1);
hold on;
plot(lambdas, covprobs(:,2), '-k', 'LineWidth', 2);
hold off;
the_xlim = xlim;
line(the_xlim, repmat(1-alpha,1,2), 'Color', 'k', 'LineStyle', '--');
grid on;
xlim(the_xlim);
ylim([min(ylim) 1]);
legend({'Parametric EBCI, worst-case distribution', ...
        'Robust EBCI, exponential distribution'}, ...
        'Location', 'East', 'FontSize', 9);
title('Coverage probability', 'FontSize', 11);
xlabel('$\lambda$', 'Interpreter', 'latex');
set(gca, 'FontSize', 9);
saveas(gcf, fullfile('../output', 'poisson_cov.eps'), 'epsc');

figure('Units', 'inches', 'Position', [0 0 4 4]);
plot(lambdas', lngs(:,1)./lngs(:,3), '--k', 'LineWidth', 1);
hold on;
plot(lambdas', lngs(:,2)./lngs(:,3), '-k', 'LineWidth', 2);
hold off;
grid on;
legend({'Parametric EBCI', 'Robust EBCI'}, 'Location', 'SouthEast', 'FontSize', 9);
title('Normalized exp. length under exponential distr.', 'FontSize', 11);
xlabel('$\lambda$', 'Interpreter', 'latex');
set(gca, 'FontSize', 9);
saveas(gcf, fullfile('../output', 'poisson_lng.eps'), 'epsc');

