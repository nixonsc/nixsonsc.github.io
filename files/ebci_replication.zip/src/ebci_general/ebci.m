function [chi_param, lng_param, worstcase_cover_param, chi_robust, lng_robust, baseline_cover_robust, lfd, marg0] ...
    = ebci(dens, prior0, marg0, constr, cover, ci_lng, ...
           alpha, grid_y, grid_theta, cont_y)

    % Parametric and robust EBCI critical values and expected lengths
    % for general form of CI, general data density, and general baseline prior
    
    % Inputs:
    % dens          fct(y,theta)        density of Y|theta
    % prior0        fct(theta)          baseline prior for theta
    % marg0         fct(y)              baseline marginal density of Y (if empty, compute numerically)
    % constr        fct(theta)          constraints E[constr(theta)]=0
    % cover         fct(y,theta,chi)    fct(y,theta,chi) that is positive when CI covers theta (if empty, use HPD)
    % ci_lng        fct(y,chi)          length of CI for given tuning parameter chi (if empty, derive length from "cover" function)
    % alpha         1 x 1               significance level
    % grid_y        1 x n_y             grid for values of Y
    % grid_theta    1 x n_theta         grid for values of theta
    % cont_y        bool                true: Y is continuous, false: Y is discrete

    % Outputs:
    % chi_param     1 x 1           tuning parameter chi for parametric EBCI
    % lng_param     1 x 1           expected length of parametric EBCI under baseline prior
    % worstcase_cover_param  1 x 1  worst-case coverage of parametric EBCI
    % chi_robust    1 x 1           tuning parameter chi for robust EBCI
    % lng_robust    1 x 1           expected length of robust EBCI under baseline prior
    % baseline_cover_robust  1 x 1  coverage of robust EBCI under baseline prior
    % lfd           1 x n_theta     least favorable distribution for robust EBCI
    % marg0         fct(y)          marginal density of Y
    
    
    % Numerically approximate marginal density of Y if not already supplied
    if isempty(marg0)
        lm = logmarg_interp(dens, prior0, grid_y, grid_theta);
        marg0 = @(y) exp(ppval(lm, y));
    end
    
    % Coverage indicator
    if isempty(cover)
        cover = @(y,theta,chi) cover_hpd(y, theta, chi, dens, prior0, marg0); % Use HPD set
    end
    
    % CI length
    if isempty(ci_lng)
        ci_lng = @(y,chi) [];
    end
    
    % Crit. val. for parametric EBCI
    warning off MATLAB:quad2d:maxFunEvalsPass;
    warning off MATLAB:quad2d:maxFunEvalsFail;
    fzero_opts = optimset('TolX', sqrt(eps));
    chi_param = fzero(@(chi) baseline_cover_lng(true, @(y,theta) cover(y,theta,chi), [], dens, prior0, marg0, grid_y, grid_theta, cont_y)-(1-alpha), 0, fzero_opts);

    % Robust crit. val.
    constr_grid = constr(grid_theta); % Compute constraints on theta grid
    linprog_opts = optimoptions('linprog', 'Display', 'off');
    the_f = @(chi) worstcase_cover(@(y,theta) cover(y,theta,chi), dens, constr_grid, grid_y, grid_theta, cont_y, linprog_opts);
    chi_robust = fzero(@(chi) the_f(chi)-(1-alpha), chi_param, fzero_opts);
    [~, lfd] = the_f(chi_robust); % Least favorable distribution
    
    % Expected lengths
    lng_param = baseline_cover_lng(false, @(y,theta) cover(y,theta,chi_param), @(y) ci_lng(y,chi_param), dens, prior0, marg0, grid_y, grid_theta, cont_y); % Parametric
    lng_robust = baseline_cover_lng(false, @(y,theta) cover(y,theta,chi_robust), @(y) ci_lng(y,chi_robust), dens, prior0, marg0, grid_y, grid_theta, cont_y); % Robust
    
    % Coverage probabilities
    worstcase_cover_param = the_f(chi_param); % Parametric EBCI under least favorable distribution
    baseline_cover_robust = baseline_cover_lng(true, @(y,theta) cover(y,theta,chi_robust), [], dens, prior0, marg0, grid_y, grid_theta, cont_y); % Robust EBCI under baseline prior
    
    warning on MATLAB:quad2d:maxFunEvalsPass;
    warning on MATLAB:quad2d:maxFunEvalsFail;

end