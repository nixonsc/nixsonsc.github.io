function cover_ind = cover_hpd(y, theta, chi, dens, prior0, marg0)

    % Function that is positive when HPD CI covers theta

    cover_ind = log(dens(y,theta))+log(prior0(theta))-log(marg0(y))+chi;

end