function [covp, lfd] = worstcase_cover(cover, dens, constr_grid, grid_y, grid_theta, cont_y, linprog_opts)

    % Worst-case EBCI coverage using discretized linear program

    ng = length(grid_theta);
    
    % Conditional coverage on grid
    cond_cover = nan(1,ng);
    for i=1:ng
        if cont_y % Continuous Y
            cond_cover(i) = integral(@(y) (cover(y,grid_theta(i))>=0).*dens(y,grid_theta(i)), grid_y(1), grid_y(end));
        else % Discrete Y
            cond_cover(i) = (cover(grid_y,grid_theta(i))>=0)*dens(grid_y,grid_theta(i))';
        end
    end
    
    % Least favorable distribution
    [lfd, covp] = linprog(cond_cover', ...
                               [], [], ...
                               [ones(1,ng); constr_grid], [1; zeros(size(constr_grid,1),1)], ...
                               zeros(ng,1), [], ...
                               linprog_opts);

end