function outp = baseline_cover_lng(compute_cover, cover, ci_lng, dens, prior0, marg0, grid_y, grid_theta, cont_y)

    % Coverage or expected length of EBCI under baseline prior

    if compute_cover
        f = @(y,theta) dens(y,theta).*prior0(theta); % Coverage
    else
        f = @(y,theta) marg0(y); % Expected length
    end

    % Compute coverage/length by numerical integration
    if cont_y % Continuous Y
        if compute_cover || isempty(ci_lng(0))
            outp = quad2d(@(y,theta) (cover(y,theta)>=0).*f(y,theta), ...
                          grid_y(1), grid_y(end), grid_theta(1), grid_theta(end), ...
                          'AbsTol', 1e-4, 'RelTol', 1e-4, 'MaxFunEvals', 1e4); % Integrate over (Y,theta)
        else
            outp = integral(@(y) ci_lng(y).*marg0(y), ...
                            grid_y(1), grid_y(end), ...
                            'AbsTol', 1e-4, 'RelTol', 1e-4); % Integrate over Y
        end
    else % Discrete Y
        if compute_cover || isempty(ci_lng(0))
            outp = integral(@(theta) (cover(grid_y,theta)>=0)*f(grid_y,theta)', ...
                            grid_theta(1), grid_theta(end), ...
                            'AbsTol', 1e-4, 'RelTol', 1e-4, 'ArrayValued', true); % Sum over Y, integrate over theta
        else
            outp = ci_lng(grid_y)*marg0(grid_y)'; % Sum over Y
        end
    end

end