function lm = logmarg_interp(dens, prior, grid_y, grid_theta)
    
    % Marginal data density by numerical integration and interpolation

    % Compute on grid
    vals = nan(size(grid_y));
    for i=1:length(vals)
        vals(i) = integral(@(theta) dens(grid_y(i),theta).*prior(theta), grid_theta(1), grid_theta(end));
    end
    
    % Interpolate log density
    lm = interp1(grid_y,log(vals),'pchip','pp');

end