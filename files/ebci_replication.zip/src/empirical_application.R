## Replicate Figures 6 and Table 3 in the main text
## Script takes 4 mins to run

sink(file="../output/empirical_application.out")

## Format for Table 3
eb_table <- function(res, wgt) {
    if(is.null(res$df$mu2)) {
        m1 <- t(matrix(c(res$mu2, res$kappa), ncol=nrow(res$df), nrow=4))
        colnames(m1) <- c("mu2", "mu_{2, init}", "kappa", "kappa_{init}")
        res$df <- cbind(res$df, m1)
    }
    res$df$"E[mu_{2i}/sigma_i^2]" <- res$df$mu2/res$df$se^2
    l1 <- vapply(res$df, weighted.mean, FUN.VALUE=numeric(1), w=wgt)
    ret <- c("E[sqrt{mu_2i}]"=mean(sqrt(res$df$mu2)),
             "E[sqrt{mu_{2i, init}}]" =
                 mean(sqrt(pmax(res$df$"mu_{2, init}", 0))),
             "E[kappa_i]"=mean(res$df$kappa),
             "E[kappa_{i, init}]"=mean(res$df$"kappa_{init}"), l1[length(l1)],
             res$delta, l1[1:7], l1[4]/l1[5:7])
    names(ret)[(length(ret)-2):length(ret)] <- c("eff_op", "eff_pa", "eff_us")
    ret
}

## 0. ################ Setup ##################
## Load Data and compute results
source("np_functions.R")
## Baseline
ts <- ebci::cz[!is.na(ebci::cz$theta25), ]
c1 <- ebci::ebci(theta25 ~ stayer25, ts, se25, 1/se25^2, wopt=TRUE)
c2 <- ebci::ebci(theta75 ~ stayer75, ts, se75, 1/se75^2, wopt=TRUE)
## Nonparametric
c12 <- ebci_np(c1, method="euclidean")
c22 <- ebci_np(c2, method="euclidean")

## 1. ################ Table 3 ##################
print(knitr::kable(cbind(c1=eb_table(c1), c2=eb_table(c2), c3=eb_table(c12),
                         c4=eb_table(c22))[-c(2, 4), ],
                   digits=3))

## normalize cv_obj
cv_stats <- function(out) {
    N <- length(out$ns)
    df <- data.frame(scale(out$cv_obj, center=FALSE, scale=out$cv_obj[N, ]))
    df$J <- out$ns
    tidyr::pivot_longer(df, !J, names_to = "name", values_to = "y")
}

d1 <- cv_stats(c12)
d2 <- cv_stats(c22)

cat("J:", c12$nn, "at 25th percentile\n  ", c22$nn, "at 75th")
cat("\nMaximum R2:\n", 1-min(d1$y[d1$name=="R2"]), "at 25th percentile\n",
    1-min(d2$y[d2$name=="R2"]), "at 75th")
cat("\nPercent of w_eb < 0.3: ", round(100*mean(c1$df$w_eb<0.3), 1), ", and ",
    round(100*mean(c2$df$w_eb<0.3), 1), "\n", sep="")

## 2. Figure 6
plotCI <- function(d0)  {
    ## So that ggplot doesn't reorder things alphabetically
    d0$name <- factor(d0$name, levels=unique(d0$name))
    d0 <- droplevels(d0)
    dt <- data.frame(x=rep(d0$x, 2), y=c(d0$th_us, d0$th_eb),
                     type=rep(c("Unshrunk", "EB"), each=nrow(d0)),
                     hl=c(d0$len_us, d0$len_eb),
                     label=c(as.character(d0$name), rep("", nrow(d0))))
    p1 <- ggplot2::ggplot(data=dt, ggplot2::aes(x=x,
                                                y=(y>0)*(y+hl)+(y<0)*(y-hl),
                                                label=label)) +
        ggplot2::geom_point(ggplot2::aes(x=x, y=y, shape=type, color=type)) +
        ggplot2::geom_errorbar(ggplot2::aes(x=x, ymin=y-hl, ymax=y+hl,
                                            color=type),
                               width=0.1) +
        ggrepel::geom_text_repel(data = subset(dt, y < 0), nudge_y = -0.1,
                                 direction="x", segment.color = "grey50",
                                 segment.alpha = 0.01, size=3, color="grey50")+
        ggrepel::geom_text_repel(data = subset(dt, y > 0), nudge_y = 0.1,
                                 direction="x", segment.color = "grey50",
                                 segment.alpha = 0.01, size=3, color="grey50")
    p1
}

idxNY <- which(ts$state=="NY")
df <- cbind(name=ts$czname, x=ts$stayer25, c1$df)
df0 <- df[idxNY, ]

ggthemr::ggthemr(palette = "greyscale", layout = "clear", spacing = 1,
                 text_size=10, type="inner")

f6 <- plotCI(df0) +
    ggplot2::labs(y="Effect of 1 year of exposure on income rank",
         x="Mean rank of children of perm.~residents at $p=25$") +
    ggplot2::theme(legend.position="none",
                   axis.text=ggplot2::element_text(size=5))+
    ggplot2::scale_shape_manual(values=c(15, 16)) +
    ggplot2::geom_abline(intercept=c1$delta[1], slope=c1$delta[2],
                                  linetype="dotted") +
    ggthemr::scale_colour_ggthemr_d()

tikzDevice::tikz("../output/ch_ny_paper_0.1.tex", width=5.7, height=3.2)
print(f6)
grDevices::dev.off()

sink()
