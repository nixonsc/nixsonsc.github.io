% Simulate theta from one of several distributions

theta = [];
kappa_true = [];
switch dgp_type % Simulate theta based on DGP
    case 'normal' % Normal distribution
        theta = sqrt(the_mu2)*randn(the_n,1);
        kappa_true = 3;
    case 'chi2' % Chi-squared distribution
        theta = sqrt(the_mu2/2)*chi2rnd(1,the_n,1);
        kappa_true = 12+3;
    case '2point' % 2-point distribution
        theta = sqrt(the_mu2/(p0_2point*(1-p0_2point)))*(rand(the_n,1)>p0_2point);
        kappa_true = 1/(p0_2point*(1-p0_2point))-3;
    case '3point' % 3-point distribution
        [theta, kappa_true] = sim_3point(the_mu2, p0_3point, the_n);
    case 'lf' % Least favorable distribution for robust EBCI (mu_2 only)
        the_p0_lf = p0_lf(find(mu2s==the_mu2,1));
        [theta, kappa_true] = sim_3point(the_mu2, the_p0_lf, the_n);
    case 'lfparam' % Least favorable distribution for parametric EBCI
        the_p0_lfparam = p0_lfparam(find(mu2s==the_mu2,1));
        [theta, kappa_true] = sim_3point(the_mu2, the_p0_lfparam, the_n);
end


%% Auxiliary function

function [theta, kappa] = sim_3point(mu2, p0, n)

    % Simulate symmetric three-point distribution
    % with Var(theta)=mu2 and P(theta=0)=p0

    theta = sqrt(mu2/(1-p0))*(rand(n,1)>p0).*(2*(rand(n,1)>0.5)-1);
    kappa = 1/(1-p0); % True kurtosis

end