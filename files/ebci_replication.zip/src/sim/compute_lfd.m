% Compute least favorable distributions

% Robust EBCI
p0_lf = nan(1,length(mu2s));
if strcmp(dgp_type, 'lf')
    for im=1:length(mu2s)
        [~, the_lf_t, the_lf_p] = cva(1/mu2s(im),Inf,alpha); % LF distribution for robust EBCI that imposes only second moment
        p0_lf(im) = 1-the_lf_p(find(the_lf_t>0,1)); % P(theta=0) of LF distribution
    end
end

% Parametric EBCI
p0_lfparam = nan(1,length(mu2s));
if strcmp(dgp_type, 'lfparam')
    for im=1:length(mu2s)
        [~, the_lf_t, the_lf_p] = rho(1/mu2s(im),Inf,norminv(1-alpha/2)/sqrt(mu2s(im)/(1+mu2s(im)))); % LF distribution for parametric EBCI
        p0_lfparam(im) = 1-the_lf_p(find(the_lf_t>0,1)); % P(theta=0) of LF distribution
    end
end