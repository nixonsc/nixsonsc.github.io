## Functions for nonparametric estimation of moments

## Local constant nearest neighbor predictor
nnpredict <- function(out, D, nn) {
    n <- nrow(out$df)
    mus <- matrix(nrow=n, ncol=4)
    mus_loo <- matrix(nrow=n, ncol=4)

    for (j in seq_len(n)) {
        idx <- (D[, j] <= sort(D[, j])[min(nn, n)])
        mus[j, ] <- ebci:::moments(out$df$residuals[idx],
                            out$df$se[idx], out$df$weights[idx])
        ## Leave one out estimate
        idx <- (D[, j] <= sort(D[, j])[min(nn+1, n)])
        idx[j] <- FALSE
        mus_loo[j, ] <- ebci:::moments(out$df$residuals[idx],
                            out$df$se[idx], out$df$weights[idx])
    }
    w2 <- out$df$residuals^2-out$df$se^2
    list(cv_objective= c("CV"=sum((w2-mus_loo[, 1])^2),
                         "R2"=sum((w2-mus[, 1])^2)), mu=mus)
}

## Augment results with nonparametric moment estimates
ebci_np <- function(out, method="euclidean", nn=NULL, kappa=NULL) {
    X <- cbind(out$X, out$df$se)
    X <- X[, diag(var(X))>0]
    D <- as.matrix(dist(scale(X), method=method))
    n <- nrow(D)

    cv_fkt <- function(J)
        nnpredict(out, D=D, nn=J)$cv_objective
    if (is.null(nn)) {
        out$ns <- seq(floor(n/20), n, by=1)
        out$cv_obj <- t(vapply(out$ns, cv_fkt, numeric(2)))
        out$nn <- out$ns[which.min(out$cv_obj[, 1])]
    } else {
        out$nn <- nn
    }
    mus <- nnpredict(out, D=D, nn=out$nn)$mu
    if(!is.null(kappa))
        mus[, 2] <- kappa

    ## Update estimates
    se <- out$df$se
    for (j in seq_len(n)) {
        out$df$len_eb[j] <- ebci::cva(se[j]^2*mus[j, 1]/out$mu2[1]^2,
                              kappa=mus[j, 2], alpha=out$alpha, check=TRUE)$cv
        out$df$len_op[j] <- ebci::cva((1-1/out$df$w_op[j])^2*mus[j, 1]/se[j]^2,
                              kappa=mus[j, 2], alpha=out$alpha, check=TRUE)$cv
        out$df$ncov_pa[j] <-
            ebci:::rho(se[j]^2*mus[j, 1]/out$mu2[1]^2, mus[j, 2],
                       stats::qnorm(1-out$alpha/2)*sqrt(1+se[j]^2/out$mu2[1]),
                       check=TRUE)$alpha

    }
    out$df$len_eb <- out$df$len_eb*out$df$w_eb*se
    out$df$len_op <- out$df$len_op*out$df$w_op*se
    colnames(mus) <- c("mu2", "kappa", "mu_{2, init}", "kappa_{init}")
    out$df <- cbind(out$df, mus)

    out
}
