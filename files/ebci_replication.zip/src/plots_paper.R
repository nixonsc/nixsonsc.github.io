## Replicate Figures 1--5 in the main text.
## Script takes 8 mins to run

sink(file="../output/plots_paper.out")

ggthemr::ggthemr(palette = "greyscale", layout = "clear", spacing = 1,
                 text_size=10, type="inner")

################## Figure 1
m2s <- seq(0, 4, length.out=10)
df1 <- expand.grid(m2=m2s, kappa=c(1, 3, Inf))
df1$cv <- vapply(seq_len(nrow(df1)),
                 function(j) ebci::cva(df1$m2[j], df1$kappa[j])$cv, numeric(1))
df1 <- rbind(df1, data.frame(m2=m2s, kappa=0, cv=sqrt(1+m2s)*qnorm(0.975)))
df1$lt <- paste0("$\\mathrm{cva}_{0.05}(m_{2}, ",
                 ifelse(df1$kappa==Inf, "\\infty", df1$kappa), ")$")
df1$lt[df1$kappa==0] <- paste0("$\\mathrm{cva}_{P, 0.05}(m_{2})$")
notheme <-  ggplot2::theme(legend.position="none")
f1 <- ggplot2::qplot(x=m2, y=cv, geom="line", data=df1, linetype=lt) +
    ggplot2::labs(x="$m_{2}$", y="Critical value") + notheme +
    directlabels::geom_dl(ggplot2::aes(label=lt), method="last.bumpup") +
    ggplot2::scale_x_continuous(breaks=scales::pretty_breaks(n=7),
                                limits=c(0, 4.99),
                                expand=ggplot2::expansion(mult=c(0, 0))) +
    ggplot2::scale_y_continuous(breaks=c(qnorm(0.975), 3:7),
                                labels=c(round(qnorm(0.975), 2), 3L:7L),
                                expand=ggplot2::expansion(mult=c(0, 0.05)))
tikzDevice::tikz("../output/cva_0.05_paper.tex", width=5.7, height=3.2)
print(f1)
grDevices::dev.off()

################## Figure 2
plot_eb <- function(alpha=0.05, kappa=c(3, Inf)) {
    ws <- seq(0.001, 0.999, length.out=100)
    par_len <- sqrt(ws)*qnorm(1-alpha/2)
    dfr <- data.frame()
    for (ka in kappa) {
        ## Optimal and robust length
        lo <- vapply(ws, function(w)
            ebci:::w_opt(w/(1-w), alpha=alpha, kappa=ka)$length, numeric(1))
        le <- vapply(ws, function(w)
            ebci:::w_eb(w/(1-w), alpha=alpha, kappa=ka)$length, numeric(1))
        labk <- ifelse(ka==Inf, "\\infty", ka)
        ## Relative length
        lab <- rep(c(paste0("Opt, $\\kappa=", labk, "$"),
                     paste0("Rob, $\\kappa=", labk, "$")), each=length(ws))
        dfr <- rbind(dfr, data.frame(w=ws, y=c(lo, le)/par_len, label=lab))
    }
    dfr
}
df2 <- plot_eb()
df2a <- plot_eb(alpha=0.1)

df2$color <- factor(grepl("Opt", df2$label, fixed = TRUE))
df2labs <- df2[round(df2$w, 4)==0.0010, ]

## ggplot2:::.pt=72.27/25.4 is conversion between points (72.27 per inch) and mm
xscale <-  ggplot2::scale_x_continuous(limits=c(0, 1),
                                breaks=((0:4)/4),
                                labels=c(0, 0.25, 0.5, 0.75, 1),
                                expand=ggplot2::expansion(mult=c(0, 0)))
xlabel <-  ggplot2::xlab("$w_{EB, i}=\\mu_{2}/(\\mu_{2}+\\sigma^2_i)$")
f2 <- ggplot2::qplot(x=w, y=y, geom="line", data=df2, linetype=label,
                     color=color) + ggplot2::ylab("Relative length") +
    notheme + xscale + xlabel +
    ggplot2::scale_y_continuous(limits=c(1, max(df2$y)),
                                expand=ggplot2::expansion(mult=c(0, 0.05))) +
    ggrepel::geom_text_repel(data=df2labs, ggplot2::aes(x=w, y=y, label=label),
                             size=10/ggplot2:::.pt, nudge_x=0.04,
                             segment.colour = NA) +
    ggthemr::scale_colour_ggthemr_d()

tikzDevice::tikz("../output/ebci_efficiency_paper.tex", width=5.7, height=3.2)
print(f2)
grDevices::dev.off()

################## Figure 3: Efficiency relative to unshrunk CI

df3 <- rbind(df2[, 1:3], df2a)
df3$alpha <- rep(c("$\\alpha=0.05$", "$\\alpha=0.1$"), each=nrow(df2))
## Multiply by sqrt(w_eb) so it's relative to unshrunk rather than parametric
df3$y <- df3$y*sqrt(df3$w)
df3 <- df3[df3$label=="Rob, $\\kappa=\\infty$", ]
df3labs <- df3[round(df3$w, 4)==0.2127, ]

f3 <- ggplot2::qplot(x=w, y=y, geom="line", data=df3, color=alpha)+
    ggplot2::ylab("Relative length") + notheme +  xscale + xlabel +
    ggrepel::geom_text_repel(data=df3labs, ggplot2::aes(x=w, y=y, label=alpha),
                             size=10/ggplot2:::.pt, nudge_x=0.07,
                             segment.colour = NA) +
    ggplot2::scale_y_continuous(limits=c(0, 1),
                                expand=ggplot2::expansion(mult=c(0, 0))) +
    ggthemr::scale_colour_ggthemr_d()

tikzDevice::tikz("../output/ebci_efficiency_unshrunk_paper.tex", width=5.7,
                 height=3.2)
print(f3)
grDevices::dev.off()

################## Decompose efficiency loss + Efficiency numbers
eff <- function(w, alpha) {
    pebci <- sqrt(w)*qnorm(1-alpha/2)
    round(100*(c(ebci:::w_opt(w/(1-w), alpha=alpha, kappa=3)$length,
      ebci:::w_eb(w/(1-w), alpha=alpha, kappa=3)$length)/pebci-1), 1)
}

cat("Percent efficiency loss of OPT and EB relative to parametric")
cat("\neff, w_eb=0.1, alpha=0.05:", eff(0.1, 0.05))
cat("\neff, w_eb=0.1, alpha=0.1:", eff(0.1, 0.1))
## Minimal efficiency
cat("\neff, w_eb=0.001^2, alpha=0.05:", eff(0.001^2, 0.05))
cat("\neff, w_eb=0.001^2, alpha=0.1:", eff(0.001^2, 0.1))
# Efficiency relative to unshrunk
cat("\nGain of EB relative to unshrunk at w_eb=0.1, alpha=0.05: ",
    1-ebci:::w_eb(1/9, alpha=0.05, kappa=Inf)$length/qnorm(1-0.05/2), "\n",
    sep="")

################## Figure 4
ws <- c(0.0001, 0.0005, seq(0.001, 1, length.out=200))
ncov_pa <- function(w, alpha=0.05)
    ebci:::rho(1/w-1, kappa=Inf, qnorm(1-alpha/2)/sqrt(w), check=TRUE)$alpha
nc <- c(vapply(ws, ncov_pa, numeric(1)),
        vapply(ws, ncov_pa, numeric(1), alpha=0.1))
df4 <- data.frame(x=rep(ws, 2), y=nc,
                  alpha=rep(c("$\\alpha=0.05$", "$\\alpha=0.1$"),
                            each=length(ws)))
df4labs <- df4[round(df4$x, 4)==0.6436, ]
f4 <- ggplot2::qplot(data=df4, x=x, y=y, color=alpha, geom="line")+
    ggplot2::ylab("Max. non-coverage probability")+
    ggrepel::geom_text_repel(data=df4labs, ggplot2::aes(x=x, y=y, label=alpha),
                             size=10/ggplot2:::.pt, nudge_y=0.01,
                             segment.colour = NA) +
    ggplot2::scale_y_continuous(breaks = scales::pretty_breaks(n = 7))+
    xscale + notheme + xlabel +
    ggplot2::geom_vline(xintercept=0.3, linetype="dashed",
                    size=0.5, color=ggthemr::swatch()[1]) +
    ggthemr::scale_colour_ggthemr_d()


tikzDevice::tikz("../output/param_noncoverage_paper.tex", width=5.7, height=3.2)
print(f4)
grDevices::dev.off()

cat("Non-coverage at ROT: ", ncov_pa(w=0.3, alpha=0.05), " and ",
    ncov_pa(w=0.3, alpha=0.1), "\n", sep="")

################## Figure 5
#' @param t epsilon/sqrt{mu_2}
#' @param w w_{EB, i}
cond_perf <- function(w, t, alpha=0.05) {
    list(mse=w^2+w*(1-w)*t^2,
         coverage= 1-ebci:::r(t^2*(1/w-1),
                              ebci::cva(1/w-1, kappa=Inf, alpha=alpha)$cv))
}

## Helper function copied from RDHonest package
## Find interval containing zero of a function, then find the zero
## Search an interval for a root of \code{f},
FindZero <- function(f, ival=1.1, negative=TRUE) {
    minval <- function(ival) if (negative==TRUE) -ival else min(1/ival, 1e-3)

    while(sign(f(ival))==sign(f(minval(ival))))
            ival <- 2*ival
    stats::uniroot(f, c(minval(ival), ival), tol=.Machine$double.eps^0.75)$root
}

## When do we start undercovering?
cond_perf_cutoff <- function(w, alpha=0.05) {
    c(mse=sqrt(1+1/w),
      coverage=FindZero(function(t)
          cond_perf(w=w, t, alpha=alpha)$coverage-1+alpha, negative=FALSE))
}
ws <- c(seq(0.01, 0.1, length.out=100), seq(0.1, 0.999, length.out=100))
df <- t(vapply(ws, cond_perf_cutoff, alpha=0.05, numeric(2)))
df5 <- data.frame(w=ws,
                 y=c(df[, "mse"], df[, "coverage"]),
                 label=rep(c("MSE", "coverage"), each=length(ws)))
df5labs <- rbind(df5[round(df5$w, 4)==0.3089 & df5$label!="MSE", ],
                 df5[round(df5$w, 4)==0.7811 & df5$label=="MSE", ])
df5labs[1, 2] <- df5labs[1, 2] + 0.15
f5 <- ggplot2::qplot(data=df5, x=w, y=y, linetype=label, geom="line")+
    ggplot2::scale_y_continuous(limits = c(0, 5),
                                expand=ggplot2::expansion(mult=c(0, 0))) +
    xscale + notheme + xlabel +
    ggplot2::ylab("$|\\varepsilon_{i}|/\\sqrt{\\mu_{2}}$") +
    ggrepel::geom_text_repel(data=df5labs, ggplot2::aes(x=w, y=y, label=label),
                             size=10/ggplot2:::.pt, nudge_y=0.1,
                             segment.colour = NA)

tikzDevice::tikz("../output/cond_coverage.tex", width=5.7, height=3.2)
print(f5)
grDevices::dev.off()


sink()
