clear all;

% EBCI simulations: write results tables for paper
% MPM 2020-06-07


%% Settings

% Overall design
design_type = 'panel'; % Either 'ch' (Chetty-Hendren) or 'panel'

% EBCIs to report
if strcmp(design_type, 'ch') % Chetty-Hendren
    procs_print = {'R2', 'ora';
                   'R2', 'PMT';
                   'R4', 'ora';
                   'R4', 'PMT';
                   'P',  'ora';
                   'P',  'PMT'}; % First column: EBCI, second column: moment estimates
    lng_benchm_ind = 3; % Index of procedure used to normalize relative length
else % Panel
    procs_print = {'R2'; 'R4'; 'P'}; % EBCIs
    lng_benchm_proc_ind = 2; % Index of EBCI procedure used to normalized relative length
    lng_benchm_T = 0; % T dimension used to normalized relative length
    error_type = 'normal'; % Either 'normal' or 'chi2'
end

% Specifications and sample sizes to report
if strcmp(design_type, 'ch')
    dgp_types_print = {'indep1'}; % DGP types to report
    ns_print = []; % Will be overwritten later
else
    dgp_types_print = strcat({'normal', '2point', '3point', 'chi2', 'lf', 'lfparam'}, strcat('_', error_type)); % DGP types to report
    ns_print = [100 200 500]; % n dimensions to report
    if strcmp(error_type, 'normal')
        Ts_print = [10 20 Inf 0]; % T dimensions to report
    else
        Ts_print = [10 20 50 0];
    end
end

% Significance level to report
alpha = 0.05;

% File names
alpha_str = sprintf('%s%02d', 'alpha', 100*alpha);
tab_folder = fullfile('../output/tables_paper', alpha_str); % Output table folder
if strcmp(design_type, 'ch')
    load_folder = fullfile('results_ch', alpha_str);
    save_suff = '_ch';
else
    load_folder = fullfile('results_panel', alpha_str);
    save_suff = strcat('_panel_', error_type);
end


%% Find indices of relevant procedures/DGPs

load(fullfile(load_folder, sprintf('%s%s%s', 'sim_', dgp_types_print{1}, '.mat')), 'avg_cov', 'procs', 'dgps');
num_dgps = size(avg_cov,1);

% Find indices of selected EBCI procedures
if size(procs,1)==2 && sum(cellfun(@isempty,procs(2,:)))>0
    procs{2,cellfun(@isempty,procs(2,:))} = '';
end
proc_inds = size(procs_print,1);
for ij=1:size(procs_print,1)
    if size(procs,1)==1
        proc_inds(ij) = find(strcmp(procs,procs_print{ij}), 1);
    else
        proc_inds(ij) = find(strcmp(procs(1,:),procs_print{ij,1}) & strcmp(procs(2,:),procs_print{ij,2}), 1);
    end
end

% Find indices of normalization DGPs (for panel simulations)
if strcmp(design_type, 'panel')
    lng_benchm_T_inds = nan(num_dgps,1);
    for ij=1:num_dgps
        lng_benchm_T_inds(ij) = find(all(dgps(:,1:end-1)==dgps(ij,1:end-1),2) & dgps(:,end)==lng_benchm_T, 1);
    end
end


%% Loop over specifications

num_types = length(dgp_types_print);
num_procs_print = length(procs_print);

avg_covs = nan(num_types,num_dgps,num_procs_print);
avg_lngs = avg_covs;

mkdir(tab_folder);

for it=1:num_types % For each design

    the_type = dgp_types_print{it};

    % Load results
    load(fullfile(load_folder, sprintf('%s%s%s', 'sim_', the_type, '.mat')));

    % Table file name
    the_tab_file = fullfile(tab_folder, sprintf('%s%s%s', 'sim_', the_type, '_'));

    % Average coverage and relative average length
    avg_covs(it,:,:) = avg_cov(:,proc_inds);
    if strcmp(design_type, 'panel')
        avg_lngs(it,:,:) = avg_lng(:,proc_inds)./avg_lng(lng_benchm_T_inds,proc_inds(lng_benchm_proc_ind));
    else
        avg_lngs(it,:,:) = avg_lng(:,proc_inds)./avg_lng(:,proc_inds(lng_benchm_ind));
    end

end


%% Worst-case coverage and average relative length

if strcmp(design_type, 'ch') % Chetty-Hendren
    ns_print = n;
    dgps = n*ones(length(mu2s_pw),1);
    dgps_print = ns_print(:);
else % Panel
    dgps_print = [repmat(ns_print(:),length(Ts_print),1) kron(Ts_print(:),ones(length(ns_print),1))];
end

num_print = size(dgps_print,1);
avg_cov_lows = nan(num_print,num_procs_print);
avg_lng_avgs = avg_cov_lows;
for in=1:num_print
    avg_cov_lows(in,:) = min(min(avg_covs(:,all(dgps(:,[1 3:end])==dgps_print(in,:),2),:),[],2),[],1);
    avg_lng_avgs(in,:) = mean(mean(avg_lngs(:,all(dgps(:,[1 3:end])==dgps_print(in,:),2),:),2),1);
end


%% Write tables

if strcmp(design_type, 'ch') % Chetty-Hendren
    avg_cov_lows_table = 100*avg_cov_lows;
    avg_lng_avgs_table = avg_lng_avgs;
    dgps_table = dgps_print;
    procs_table = procs_print';
else % Panel
    % Reshape results so n goes along rows and T along columns
    avg_cov_lows_table = reshape(100*avg_cov_lows,length(ns_print),[]);
    avg_lng_avgs_table = reshape(avg_lng_avgs,length(ns_print),[]);
    dgps_table = ns_print(:);
    procs_table = [reshape(repmat(procs,length(Ts_print),1),1,[]);
                   repmat(num2cell(Ts_print),1,num_procs_print)];
end

write_tab(procs_table, dgps_table, avg_cov_lows_table, '4.1f', fullfile(tab_folder, strcat('avg_cov_lows', save_suff)));
write_tab(procs_table, dgps_table, avg_lng_avgs_table, '4.2f', fullfile(tab_folder, strcat('avg_lng_avgs', save_suff)));


%% Auxiliary function

function write_tab(procs, dgps, M, fmt, fn)

    % Write csv
    fn_csv = sprintf('%s%s', fn, '.csv');
    writecell([[cell(size(procs,1)-1,1); {'n'}], procs], fn_csv);
    dlmwrite(fn_csv, [dgps M], '-append');
    
    % Write tex
    fileID = fopen(strcat(fn, '.tex'), 'w');

    for i=1:size(M,1)
        fprintf(fileID, '%s%d%s', '$n=', dgps(i,1), '$');
        for j=1:size(M,2)
            fprintf(fileID, strcat('%s%', fmt), ' & ', M(i,j));
        end
        fprintf(fileID, '%s\n', ' \\');
    end

    fclose(fileID);

end



