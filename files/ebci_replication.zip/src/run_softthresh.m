clear all;
addpath('ebci_general');

% Robust EBCI for soft thresholding

% MPM 2021-01-19


%% Settings

% Sampling density and baseline prior
dens = @(y,theta) normpdf(y-theta);                             % Density for Y|theta
prior0 = @(theta,mu2) exp(-abs(theta)/sqrt(mu2/2))/sqrt(2*mu2); % Baseline Laplace prior
marg0 = @(y,mu2) exp(-0.5*y.^2).*(erfcx(1/sqrt(mu2)-y/sqrt(2))+erfcx(1/sqrt(mu2)+y/sqrt(2)))/(2*sqrt(2*mu2)); % Marginal density for Y under baseline prior
marg_alt = @(y,mu2) normpdf(y,0,sqrt(1+mu2));                   % Marginal density for Y under alternative prior used to calculate exp'd length below

% Moment constraint function
constr = @(theta,mu2) theta.^2-mu2;

% Significance level
alpha = 0.05;

% CI to calibrate
aux = @(y,chi,mu2,s1,s2) y-s1*sqrt(2/mu2) ...
                         + s2*sqrt((y-s1*sqrt(2/mu2)).^2 ...
                                    +2*(-0.5*log(4*pi*mu2)-log(marg0(y,mu2))+chi-0.5*y.^2) ...
                                   );
ci_lb = @(y,chi,mu2) max(aux(y,chi,mu2,-1,-1),aux(y,chi,mu2,1,-1)); % Lower endpoint
ci_ub = @(y,chi,mu2) min(aux(y,chi,mu2,-1,1),aux(y,chi,mu2,1,1)); % Upper endpoint

% Plot and numerical settings
save_on = true;                     % Save results+figures?
mu2s = 0.05:0.025:2;                % Signal-to-noise ratios
grid_theta = linspace(-10,10,500);  % Grid for theta in linear program
grid_y = [-10,10];                  % Integration endpoints for Y


%% Compute EBCIs

nv = length(mu2s);
chis = nan(nv,2);
lngs = nan(nv,2);
covprobs = nan(nv,2);
lfds = nan(nv,length(grid_theta));

% Lengths of other CIs
lng_unshr = 2*norminv(1-alpha/2); % Unshrunk

timer = tic;

% Compute EBCIs for each value of mu2
parfor ii=1:nv
% for ii=1:nv

    fprintf('%2d/%2d\n', ii, nv);
    the_mu2 = mu2s(ii);
    the_prior0 = @(theta) prior0(theta,the_mu2);
    the_marg0 = @(y) marg0(y,the_mu2);
    
    the_chis = nan(1,2);
    the_lngs = nan(1,2);
    the_covprobs = nan(1,2);
    
    % Parametric and robust EBCIs based on soft thresholding 
    [the_chis(1), the_lngs(1), the_covprobs(1), the_chis(2), the_lngs(2), the_covprobs(2), lfds(ii,:)] ...
        = ebci(dens, ...
               the_prior0, ...
               the_marg0, ...
               @(theta) constr(theta,the_mu2), ...
               [], ... % HPD set
               @(y,chi) ci_ub(y,chi,the_mu2)-ci_lb(y,chi,the_mu2), ... % CI length
               alpha, grid_y, grid_theta, true);
    
    chis(ii,:) = the_chis;
    covprobs(ii,:) = the_covprobs;
    lngs(ii,:) = the_lngs;
    
end

elapsed_time = toc(timer);
disp('Elapsed time (min):');
disp(elapsed_time/60);


%% Save results

if save_on
    mkdir('results');
    save(fullfile('results', 'softthresh'));
end


%% Figures

figure('Units', 'inches', 'Position', [0 0 4 4]);
plot(mu2s, covprobs(:,1), '--k', 'LineWidth', 1);
hold on;
plot(mu2s, covprobs(:,2), '-k', 'LineWidth', 2);
hold off;
the_xlim = xlim;
line(the_xlim, repmat(1-alpha,1,2), 'Color', 'k', 'LineStyle', ':');
grid on;
xlim(the_xlim);
ylim([min(ylim) 1]);
legend({'Parametric EBCI, worst-case distribution', ...
        'Robust EBCI, Laplace distribution'}, ...
        'Location', 'SouthEast', 'FontSize', 9);
title('Coverage probability', 'FontSize', 11);
xlabel('$\mu_2/\sigma^2$', 'Interpreter', 'latex');
set(gca, 'FontSize', 9);
if save_on
    saveas(gcf, fullfile('../output', 'softthresh_cov.eps'), 'epsc');
end

figure('Units', 'inches', 'Position', [0 0 4 4]);
plot(mu2s, lngs(:,1)/lng_unshr, '--k', 'LineWidth', 1);
hold on;
plot(mu2s, lngs(:,2)/lng_unshr, '-k', 'LineWidth', 2);
hold off;
grid on;
legend({'Parametric EBCI', 'Robust EBCI'}, 'Location', 'SouthEast', 'FontSize', 9);
title('Normalized exp. length under Laplace distr.', 'FontSize', 11);
xlabel('$\mu_2/\sigma^2$', 'Interpreter', 'latex');
set(gca, 'FontSize', 9);
if save_on
    saveas(gcf, fullfile('../output', 'softthresh_lng.eps'), 'epsc');
end
