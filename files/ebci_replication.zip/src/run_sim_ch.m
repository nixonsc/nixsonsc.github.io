clear all;
addpath('ebci');

% EBCI simulation: Chetty-Hendren (2018) application
% MPM 2020-05-19


%% Settings

% DGP
mu2s_pw = [0.1 0.5 1]; % Values of precision-weighted mu2 to loop over
indep = true; % true = impose independence between theta_i and sigma_i in DGP

% Significance level
alpha = 0.05;

% EBCI procedures
ebci_procs = {'R2', 'R2t', 'R4', 'R4t', 'P', 'Pt'}; % EBCI procedures
fs_corrs = {'ora', 'PMT'}; 'FPLIB'; % Finite-sample correction methods
use_weights = true; % true = use precision weights, false = no weighting

% Simulation settings
numrep = 2e3; % Number of Monte Carlo repetitions
numrep_ora_tstat = 1e6; % Number of draws for computing oracle values of mu_2 and kappa for t-statistic shrinkage
quants = [0.25 0.5 0.75]; % Quantiles of hat{mu2} and hat{kappa} to store
rng_seed = 202005212; % Random number seed
poolobj = parpool;

% Files
load_csv = fullfile('sim', 'ch_estimates25.csv');
save_folder = fullfile('results_ch', sprintf('%s%02d', 'alpha', 100*alpha)); % Results folder 
save_file = sprintf('%s%d%s', 'sim_indep', indep, '.mat'); % File name for storing results


%% Load estimation results

% Load from CSV
dat_estim = readtable(load_csv);
theta_vals = dat_estim.theta25;
sigma_vals = dat_estim.se25;
n = length(theta_vals); % Sample size

% True moments
mean_theta_data = mean(theta_vals); % True E[theta]
var_theta_data = var(theta_vals,1); % True Var(theta)
kurt_theta_data = kurtosis(theta_vals); % True kurtosis(theta)

mean_inv_sigma2_data = mean(1./sigma_vals.^2);
mu2_pw_data_indep = var_theta_data*mean_inv_sigma2_data; % True precision-weighted mu_2 under independence (before scaling)
mu2_pw_data = mean((theta_vals-mean_theta_data).^2./sigma_vals.^2); % True precision-weighted mu_2 w/o independence (before scaling)

scaling_factor = indep*mu2_pw_data_indep + (1-indep)*mu2_pw_data; % Scaling factor used for simulating theta below


%% Initialize results matrices

numdgp = length(mu2s_pw);

num_ebci_procs = length(ebci_procs);
num_fs_corrs = length(fs_corrs);
numproc = num_ebci_procs*num_fs_corrs; % Total number of CI procedures
procs = cell(2,numproc);
procs(1,:) = repmat(ebci_procs, 1, num_fs_corrs);
procs(2,:) = reshape(repmat(fs_corrs,num_ebci_procs,1),1,[]);

numquant = length(quants);
avg_cov = nan(numdgp, numproc);
avg_lng = avg_cov;
quant_mu2hat = nan(numdgp, numproc, numquant);
quant_kappahat = quant_mu2hat;


%% Simulate

rng(rng_seed);
disp('Simulating...');
timer = tic;

for id=1:numdgp
    
    the_mu2_pw = mu2s_pw(id);
    fprintf('%2d%s%2d%s%3.1f\n', id, '/', numdgp, ': mu2_pw=', the_mu2_pw);
    
    % Compute by simulation the oracle values of mu_2 and kappa for t-statistic shrinkage
    the_inds = randi(n,numrep_ora_tstat,2); % Random indices
    theta = mean_theta_data + sqrt(the_mu2_pw/scaling_factor)*(theta_vals(the_inds(:,1))-mean_theta_data); % Draw theta from data, scale to desired precision-weighted mu_2
    sigma = sigma_vals(the_inds(:,1+indep)); % Draw sigma from data
    mu2_ora_tstat = var(theta./sigma);
    kappa_ora_tstat = kurtosis(theta./sigma);
    
	rngs = randi(2^32-1,numrep,1); % Seeds
    
    % Initialize results matrices
    the_avg_cov = nan(numrep, numproc);
    the_avg_lng = the_avg_cov;
    the_mu2hat = nan(numrep, numproc);
    the_kappahat = the_mu2hat;
    
    for ir=1:numrep % For each Monte Carlo repetition...
        
        the_cis = cell(1,numproc);
        
        % Simulate data
        rng(rngs(ir)); % Set random seed
        the_inds = randi(n,n,2); % Random indices
        theta = mean_theta_data + sqrt(the_mu2_pw/scaling_factor)*(theta_vals(the_inds(:,1))-mean_theta_data); % Draw theta from data, scale to desired precision-weighted mu_2
        sigma = sigma_vals(the_inds(:,1+indep)); % Draw sigma from data
        Y = theta + sigma.*randn(n,1); % Simulate Y
        
        % Covariates
        X = ones(n,1); % Shrinkage towards the grand mean
        
        % Run parametric/robust EBCI procedures
        for ip=1:numproc % For each type of EBCI procedure
            
            % Determine procedure settings
            param = ismember(procs(1,ip), {'P', 'Pt'});
            use_kappa = ismember(procs(1,ip), {'R4', 'R4t'});
            tstat = ismember(procs(1,ip), {'R2t', 'R4t', 'Pt'});
            
            weights = [];
            if use_weights && ~tstat
                weights = 1./(sigma.^2); % Precision weights
            end
            
            mu2 = [];
            kappa = [];
            if strcmp(procs(2,ip), 'ora') % Oracle values of mu_2 and kappa
                if ~tstat
                    mu2 = var_theta_data*(the_mu2_pw/scaling_factor);
                    kappa = kurt_theta_data;
                else
                    mu2 = mu2_ora_tstat;
                    kappa = kappa_ora_tstat;
                end
                the_fs_corr = 'none';
            else
                the_fs_corr = procs{2,ip};
            end

            % Compute EBCI
            try
            [~, the_cis{ip}, ~, ~, the_mu2hat(ir,ip), the_kappahat(ir,ip)] = ...
                ebci(Y, X, sigma, alpha, ...
                     'tstat', tstat, 'param', param, 'use_kappa', use_kappa, 'weights', weights, 'fs_correction', the_fs_corr, 'mu2', mu2, 'kappa', kappa);
            catch ME
                sprintf('%s%d%s%d%s%d%s%d\n', 'id=', id, ', ir=', ir, ', ip=', ip, ', rng=', rngs(ir));
                warning(ME.message);
                the_cis{ip} = nan(n,2);
            end

        end

        % Compute coverage and length of CIs
        for ii=1:numproc
            the_avg_cov(ir,ii) = nanmean((the_cis{ii}(:,1)<=theta & the_cis{ii}(:,2)>=theta) ...
                                         .* sign(1+abs(sum(the_cis{ii},2)))); % Only include non-NaN;
            the_avg_lng(ir,ii) = nanmean(the_cis{ii}(:,2)-the_cis{ii}(:,1));
        end
        
        % Print progress
        if mod(ir, ceil(numrep/50))==0
            fprintf('%s%3d%s\n', repmat(' ',1,floor(50*ir/numrep)), round(100*ir/numrep), '%');
        end
        
    end
    
    % Store results from this DGP
    avg_cov(id,:) = nanmean(the_avg_cov, 1);
    avg_lng(id,:) = nanmean(the_avg_lng, 1);
    quant_mu2hat(id,:,:) = quantile(the_mu2hat, quants, 1)';
    quant_kappahat(id,:,:) = quantile(the_kappahat, quants, 1)';
    
end

elapsed_time = toc(timer);
disp('Done. Elapsed time (minutes):');
disp(elapsed_time/60);

delete(poolobj);


%% Save

mkdir(save_folder);
save(fullfile(save_folder, save_file));

