## Takes 20 Mins

## Figure S1: Power as a function of normalized distance d and shrinkage

## d=(mu1-theta0)/sigma
ebci_power <- function(d, w)
    ebci:::r(d^2*(1-w)/w^2,
             ebci::cva(1/w-1, kappa=3, alpha=0.05)$cv*sqrt(1-w))

z_power <- function(d, w)
    ebci:::r(d^2*(1-w), qnorm(0.975)*sqrt(1-w))

gr <- expand.grid(ds=c(seq(0, 0.7, length.out=50),
                       seq(0.71, 2.5, length.out=70)),
                  w=c(seq(0.01, 0.1, length.out=20),
                      seq(0.11, 0.99, length.out=40)))
df1 <- vapply(seq_len(nrow(gr)), function(j) ebci_power(gr[j, 1], gr[j, 2]),
              numeric(1))
df2 <- vapply(seq_len(nrow(gr)), function(j) z_power(gr[j, 1], gr[j, 2]),
              numeric(1))

ggthemr::ggthemr(palette = "greyscale", layout = "clear", spacing = 1,
                 text_size=10, type="inner")

labs <- rep(c("Robust EBCI", "$z$-test", "Power Difference"), each=nrow(gr))
labs <- factor(labs, levels=unique(labs))
nd1 <- data.frame(z=c(df1, df2, df1-df2), d=rep(gr$ds, 3), w=rep(gr$w, 3),
                  type=labs)

fs1 <- ggplot2::ggplot(data=nd1) +
    ggplot2::stat_contour(ggplot2::aes(x = d, y = w, z = z),
                          breaks=c(-0.1, 0, 0.1, 0.2, 0.5, 0.9),
                          color="#777777") +
    ggplot2::facet_wrap(ggplot2::vars(type), nrow=3) +
    metR::geom_text_contour(ggplot2::aes(x = d, y = w, z = z), stroke=0.3,
                            skip=0, breaks=c(-0.1, 0, 0.1, 0.2, 0.5, 0.9),
                            size=3,
                            label.placer=metR::label_placer_n(n=1)) +
    ggplot2::scale_x_continuous(expand=ggplot2::expansion(mult=c(0, 0))) +
    ggplot2::scale_y_continuous(limits=c(0, 1),
                                expand=ggplot2::expansion(mult=c(0, 0))) +
    ggplot2::labs(x="$(\\mu_1-\\theta_0)/\\sigma_i$", y="$w_{EB, i}$")

tikzDevice::tikz(paste0("../output/power_difference.tex"), width=5.7,
                 height=6.5, verbose=FALSE)
print(fs1)
grDevices::dev.off()
