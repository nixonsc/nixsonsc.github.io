clear all;
addpath('ebci', 'sim');

% EBCI simulations with panel data
% MPM 2021-01-26


%% Settings

% Choose overall experiment
id = 1; % Experiment ID (number between 1 and 12)
dgp_types = {'normal', '2point', '3point', 'chi2', 'lf', 'lfparam'}; % Possible theta distributions
if id<=length(dgp_types)
  error_type = 'normal';    % Distribution of idiosyncratic panel errors
  dgp_type = dgp_types{id}; % Distribution of theta (fixed effects)
else
  error_type = 'chi2';
  dgp_type = dgp_types{id-length(dgp_types)};
end

% Other DGP settings
ns = [100 200 500];     % Values of n to loop over
mu2s = [0.1 0.5 1 2];   % Values of mu_2 to loop over
Ts = [10 20 50 Inf 0];  % Values of T (panel time dimension) to loop over
                        % (=Inf: exact normal, oracle sigma; =0: exact normal, oracle sigma and moments)
p0_2point = 0.9;        % P(theta=0) in 2-point distribution DGP
p0_3point = 0.5;        % P(theta=0) in 3-point distribution DGP

% Significance level
alpha = 0.05;

% EBCI procedures
procs = {'R2', 'R4', 'P'};  % 'R2o'; 'R4o'; % EBCI procedures
fs_corr = 'PMT';            % 'none'; 'FPLIB'; % Finite-sample correction method
use_weights = true;          % true = precision weights, false = equal weights

% Simulation settings
numrep = 2e3;               % Number of Monte Carlo repetitions
quants = [0.25 0.5 0.75];   % Quantiles of hat{mu2} and hat{kappa} to store
rng_seed = 202102121;       % Random number seed
poolobj = parpool;

% Files
save_folder = fullfile('results_panel', sprintf('%s%02d', 'alpha', 100*alpha)); % Results folder 
save_file = sprintf('%s%s%s%s%s', 'sim_', dgp_type, '_', error_type, '.mat');   % File name for storing results


%% Compute least favorable distributions

compute_lfd;


%% Initialize results matrices

dgps = combvec(ns, mu2s, Ts)';
numdgp = size(dgps,1);

numproc = length(procs);
numquant = length(quants);
avg_cov = nan(numdgp, numproc);
avg_lng = avg_cov;
quant_mu2hat = nan(numdgp, numproc, numquant);
quant_kappahat = quant_mu2hat;


%% Simulate

rng(rng_seed, 'twister');
disp('Simulating...');
timer = tic;

for id=1:numdgp
    
    the_n = dgps(id,1);
    the_mu2 = dgps(id,2);
    the_T = dgps(id,3);
    fprintf('%2d%s%2d%s%4d%s%3.1f%s%3d\n', id, '/', numdgp, ': n=', the_n, ', mu2=', the_mu2, ', T=', the_T);
    
    % Initialize results matrices
    the_avg_cov = nan(numrep, numproc);
    the_avg_lng = the_avg_cov;
    the_mu2hat = nan(numrep, numproc);
    the_kappahat = the_mu2hat;
    
    for ir=1:numrep % For each Monte Carlo repetition...
        
        the_cis = cell(1,numproc);
        the_mu2hat_par = nan(1,numproc);
        the_kappahat_par = the_mu2hat_par;
        
        % Simulate data
        sim_theta; % Simulate theta
        
        if the_T>0 && the_T<Inf
            
            % Obtain Y from panel data
            switch error_type
                case 'normal' % Normal distribution
                    U = randn(the_n,the_T)*sqrt(the_T); % Scale so Var(avg(U))=1
                case 'chi2' % Chi-squared(3) distribution
                    U = (chi2rnd(3,the_n,the_T)-3)*sqrt(the_T/6);
            end
            W = theta + U; % Panel data W
            Y = mean(W,2); % Unshrunk fixed effect estimates Y
            sigma_hat = sqrt(var(W,0,2)/the_T); % Feasible standard errors
            
        else
            
            % Exact normal Y with known sigma
            Y = theta + randn(the_n,1);
            sigma_hat = 1;
            
        end
        
        % Covariates
        X = ones(the_n,1); % Shrinkage towards the grand mean
        
        % Run EBCI procedures
        for ip=1:numproc % For each type of EBCI procedure
            
            % Determine procedure settings
            param = strcmp(procs(ip), 'P');
            use_kappa = ismember(procs(ip), {'R4', 'R4o'});
            w_opt = ismember(procs(ip), {'R2o', 'R4o'});

            mu2 = [];
            kappa = [];
            if the_T==0 || strcmp(fs_corr, 'ora') % Use oracle values of mu_2 and kappa
                mu2 = the_mu2;
                kappa = kappa_true;
                the_fs_corr = 'none';
            else
                the_fs_corr = fs_corr;
            end
            
            weights = [];
            if use_weights && length(sigma_hat)>1
                weights = 1./(sigma_hat.^2); % Precision weights
            end

            % Compute EBCI
            try
                [~, the_cis{ip}, ~, ~, the_mu2hat_par(ip), the_kappahat_par(ip)] = ...
                    ebci(Y, X, sigma_hat, alpha, ...
                         'tstat', length(sigma_hat)==1, ...
                         'param', param, ...
                         'use_kappa', use_kappa, ...
                         'w_opt', w_opt, ...
                         'fs_correction', the_fs_corr, ...
                         'mu2', mu2, ...
                         'kappa', kappa, ...
                         'weights', weights);
            catch ME
                sprintf('%s%d%s%d%s%d\n', 'id=', id, ', ir=', ir, ', ip=', ip);
                warning(ME.message);
                the_cis{ip} = nan(the_n,2);
            end
            
        end
        
        % Compute coverage and length of CIs
        the_avg_cov_par = nan(1, numproc);
        the_avg_lng_par = the_avg_cov_par;
        for ii=1:numproc
            the_avg_cov_par(ii) = nanmean((the_cis{ii}(:,1)<=theta & the_cis{ii}(:,2)>=theta) ...
                                          .* sign(1+abs(sum(the_cis{ii},2)))); % Only include non-NaN
            the_avg_lng_par(ii) = nanmean(the_cis{ii}(:,2)-the_cis{ii}(:,1));
        end
        
        % Store results from this repetition
        the_avg_cov(ir,:) = the_avg_cov_par;
        the_avg_lng(ir,:) = the_avg_lng_par;
        the_mu2hat(ir,:) = the_mu2hat_par;
        the_kappahat(ir,:) = the_kappahat_par;
        
        % Print progress
        if mod(ir, ceil(numrep/50))==0
            fprintf('%s%3d%s\n', repmat(' ',1,floor(50*ir/numrep)), round(100*ir/numrep), '%');
        end
        
    end
    
    % Store results from this DGP
    avg_cov(id,:) = nanmean(the_avg_cov, 1);
    avg_lng(id,:) = nanmean(the_avg_lng, 1);
    quant_mu2hat(id,:,:) = quantile(the_mu2hat, quants, 1)';
    quant_kappahat(id,:,:) = quantile(the_kappahat, quants, 1)';
    
end

elapsed_time = toc(timer);
disp('Done. Elapsed time (minutes):');
disp(elapsed_time/60);

delete(poolobj);


%% Save

mkdir(save_folder);
save(fullfile(save_folder, save_file));

