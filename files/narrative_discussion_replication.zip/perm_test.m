function [stat_sample, stat_cv] = perm_test(sample1,sample2,stat_fct,num_perm,signif_level)

    % Permutation test of independence
    
    n = length(sample1);
    stat_sample = stat_fct(sample1,sample2); % Statistic computed on actual sample
    stat_perm = nan(1,num_perm);
    for j=1:num_perm % For each permutation...
        stat_perm(j) = stat_fct(sample1(randperm(n)),sample2); % Statistic when sample1 is randomly permuted
    end
    stat_cv = quantile(stat_perm,1-signif_level); % Critical value

end