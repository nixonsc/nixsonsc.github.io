% Monte Carlo simulation of permutation test for
% SVAR identification through narrative restrictions

% MPM 2021-12-16

clear all;


%% Settings

% DGP
T = 500;                            % Sample size
Ks = [5,20,50];                     % #periods when we observe sign of first shock
irs_true = [0.5 -0.5; 0.2 1.8];     % True impulse responses

% Estimation/inference
stat_fct = @(z,y) abs(corr(z,y));   % Statistic for permutation test
signif_level = 0.05;                % Significance level
ir_power = -1:0.1:1;                % Values of relative IR to test, in deviations from true value

% Numerical
num_sim = 5e3;                      % #repetitions
num_perm = 1e3;                     % #permutations per repetition
rng(20211216, 'twister');           % Seed RNG

% Power plot
line_colors = lines(3);             % Colors of curves for each value of K
line_styles = {'-', '--', '-.'};    % Line styles for curves


%% Monte Carlo

ir_true = irs_true(2,1)/irs_true(1,1); % Relative IR parameter of interest
num_power = length(ir_power);
num_K = length(Ks);

stats = nan(num_sim,num_power,num_K);
stats_cv = nan(num_sim,num_power,num_K);
rngs = randi(2^32-1,1,num_sim); % Random seeds for parallel workers

timer = tic;

parfor s=1:num_sim % For each repetition...
    
    the_stats = nan(num_power,num_K);
    the_stats_cv = nan(num_power,num_K);
    
    % Simulate data
    rng(rngs(s), 'twister');
    shocks = randn(T,2);
    Y = shocks*irs_true';
    
    for k=1:num_K % For each value of K...
        
        % Generate proxy
        K = Ks(k);
        Z = zeros(T,1);
        Z(find(shocks(:,1)>0,K)) = 1; % Time periods of first K positive shock_1 realizations

        % Permutation test
        for p=1:num_power % For each alternative...
            shock2_under_null = Y(:,2)-(ir_true+ir_power(p))*Y(:,1); % Shock_2 (up to scale), imputed under the null hypothesis
            [the_stats(p,k),the_stats_cv(p,k)] = perm_test(Z,shock2_under_null,stat_fct,num_perm,signif_level); % Test independence of Z and imputed shock_2
        end
    
    end
    
    % Store results
    stats(s,:,:) = the_stats;
    stats_cv(s,:,:) = the_stats_cv;
    
    % Show progress
    if mod(s,ceil(num_sim/50))==0
        fprintf('%s%3d%s\n', repmat(' ',1,round(50*s/num_sim)), round(100*s/num_sim), '%');
    end
    
end

elapsed_time = toc(timer);
disp('Elapsed time (min.)');
disp(elapsed_time/60);

save('sim'); % Save results


%% Results

rej_freq = permute(mean(stats>stats_cv,1),[2 3 1]); % Rejection frequencies

figure('Units', 'inches', 'Position', [1 1 9 5]);
hold on;
for k=1:num_K
    plot(ir_power, rej_freq(:,k), 'Color', line_colors(k,:), 'LineStyle', line_styles{k}, 'LineWidth', 2);
end
hold off;
the_xlim = xlim;
the_ylim = ylim;
the_ylim(1) = 0;
line(the_xlim, signif_level*ones(1,2), 'Color', 'k', 'LineStyle', ':');
line([0 0], the_ylim, 'Color', 'k');
xlim(the_xlim);
ylim(the_ylim);
xlabel('$\bar{\eta}-\tilde{\eta}_{21}$', 'Interpreter', 'Latex');
ylabel('power');
legend(strcat(strcat('K=',arrayfun(@num2str, Ks, 'UniformOutput', false))), 'Location', 'NorthEast', 'FontSize', 14);
set(gca,'FontSize',14);


