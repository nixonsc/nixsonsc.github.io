Replication files for:

"Discussion of 'Narrative Restrictions and Proxies' by Raffaella Giacomini, Toru Kitagawa, and Matthew Read"
by Mikkel Plagborg-Moller (mikkelpm@princeton.edu)

January 25, 2022


CONTENTS:
- run_sim.m: Executes simulation study
- perm_test.m: Function for Fisher permutation test of independence

INSTRUCTIONS:
To replicate Figure 1, run the file "run_sim.m" in Matlab.

REQUIREMENTS:
The code requires Matlab's Parallel Computing Toolbox. It has been tested in Matlab R2021a on a Windows 10 PC.

ACKNOWLEDGEMENTS:
I acknowledge that this material is based upon work supported by the NSF under Grant #1851665. Any opinions, findings, and conclusions or recommendations expressed in this material are those of the author and do not necessarily reflect the views of the NSF.
